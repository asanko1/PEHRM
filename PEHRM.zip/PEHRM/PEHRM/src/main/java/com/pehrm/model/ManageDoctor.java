package com.pehrm.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.cj.jdbc.CallableStatement;
import com.pehrm.bean.DOCTOR_INFO;
import com.pehrm.bean.DOCTOR_INFO;
import com.pehrm.config.DBConnection;

public class ManageDoctor {
	public String createDoctor(DOCTOR_INFO DI) {
		DBConnection dbcon = new DBConnection();
		String pkey = null;
		Connection con = dbcon.getDBConnection();
		try {

			String query = "{CALL sp_get_pkey(?,?,?)}";
			CallableStatement stmt = (CallableStatement) con.prepareCall(query);
			stmt.setString(1, "Doctor_Info");
			stmt.setString(2, "ID");
			stmt.registerOutParameter(3, java.sql.Types.VARCHAR);
			stmt.executeQuery();
			pkey = stmt.getString(3);

			System.out.println(pkey);
			DI.setID(pkey);
			PreparedStatement ps = con
					.prepareStatement("INSERT INTO Doctor_Info values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			ps.setString(1, DI.getID());
			ps.setString(2, DI.getFirstName());
			ps.setString(3, DI.getLastName());
			ps.setString(4, DI.getPhone());
			ps.setString(5, DI.getEmaiil());
			ps.setString(6, DI.getDegree());
			ps.setString(7, DI.getSpecialization());
			ps.setString(8, DI.getExperienceSummary());
			ps.setString(9, DI.getRegistrationNo());
			ps.setString(10, DI.getRegistrationAuthority());
			ps.setDate(11,  new java.sql.Date(DI.getCreatedOn().getTime()));
			ps.setString(12, DI.getCreatedBy());
			ps.setDate(13, new java.sql.Date(DI.getLastUpdatedOn().getTime()));
			ps.setString(14, DI.getLastUpdatedBy());
			ps.setString(15, DI.getOrgCode());
			ps.executeUpdate();
			
			ps = con.prepareStatement("INSERT INTO login(email,password,name,OrgCode,usertype) values (?,?,?,?,?)");
			ps.setString(1, DI.getEmaiil());
			ps.setString(2, "XzYu6!");
			ps.setString(3, DI.getFirstName());
			ps.setString(4, DI.getOrgCode());
			ps.setString(5, "doc");
			ps.executeUpdate();
			
			con.close();
			
			
			return pkey;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pkey;
	}
	
	public ArrayList<DOCTOR_INFO> searchDoctor(String phone, String OrgCode) {
		DBConnection dbcon=new DBConnection();
		Connection con=dbcon.getDBConnection();
		DOCTOR_INFO DI=null;
		ArrayList<DOCTOR_INFO> doc_arr=new ArrayList<DOCTOR_INFO>();
		try {
			PreparedStatement ps=con.prepareStatement("SELECT * FROM Doctor_Info WHERE Phone=? and OrgCode=? LIMIT 5");
			ps.setString(1, phone);
			ps.setString(2, OrgCode);
			 DI=new DOCTOR_INFO();
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				DI=new DOCTOR_INFO();
				DI.setID(rs.getString(1));
				DI.setFirstName(rs.getString(2));
				DI.setLastName(rs.getString(3));
				DI.setPhone(rs.getString(4));
				DI.setEmaiil(rs.getString(5));
				DI.setDegree(rs.getString(6));
				DI.setSpecialization(rs.getString(7));
				DI.setRegistrationAuthority(rs.getString(10));
				DI.setRegistrationNo(rs.getString(9));
				doc_arr.add(DI);
			}
			con.close();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return doc_arr;
	}
	public DOCTOR_INFO getDoctor(String id, String OrgCode) {
		DBConnection dbcon=new DBConnection();
		Connection con=dbcon.getDBConnection();
		DOCTOR_INFO DI=null;
		
		try {
			PreparedStatement ps=con.prepareStatement("SELECT * FROM Doctor_Info WHERE ID=? and OrgCode=? LIMIT 1");
			ps.setString(1, id);
			ps.setString(2, OrgCode);
			 DI=new DOCTOR_INFO();
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				DI=new DOCTOR_INFO();
				DI.setID(rs.getString(1));
				DI.setFirstName(rs.getString(2));
				DI.setLastName(rs.getString(3));
				DI.setPhone(rs.getString(4));
				DI.setEmaiil(rs.getString(5));
				DI.setDegree(rs.getString(6));
				DI.setSpecialization(rs.getString(7));
				DI.setRegistrationAuthority(rs.getString(10));
				DI.setRegistrationNo(rs.getString(9));
				
			}
			con.close();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return DI;
	}
	public ArrayList<DOCTOR_INFO> getAllDoctor(String ccode) {
		DBConnection dbcon=new DBConnection();
		Connection con=dbcon.getDBConnection();
		DOCTOR_INFO DI=null;
		ArrayList<DOCTOR_INFO> doc_arr=new ArrayList<DOCTOR_INFO>();
		try {
			PreparedStatement ps=con.prepareStatement("SELECT * FROM Doctor_Info WHERE OrgCode=?");
			ps.setString(1, ccode);
			 DI=new DOCTOR_INFO();
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				DI=new DOCTOR_INFO();
				DI.setID(rs.getString(1));
				DI.setFirstName(rs.getString(2));
				DI.setLastName(rs.getString(3));
				DI.setPhone(rs.getString(4));
				DI.setEmaiil(rs.getString(5));
				DI.setDegree(rs.getString(6));
				DI.setSpecialization(rs.getString(7));
				DI.setRegistrationAuthority(rs.getString(10));
				DI.setRegistrationNo(rs.getString(9));
				doc_arr.add(DI);
			}
			con.close();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return doc_arr;
	}
	
	public String searchDoctorByID(String pid, String OrgCode) {
		DBConnection dbcon=new DBConnection();
		Connection con=dbcon.getDBConnection();
		String name=null;
		try {
			PreparedStatement ps=con.prepareStatement("SELECT concat(FirstName,' ',LastName) FROM Doctor_Info WHERE ID=? and OrgCode=?");
			ps.setString(1, pid);
			ps.setString(2, OrgCode);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				name=rs.getString(1);
			}
			con.close();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return name;
	}
	
	public String getDoctorEmailId(String pid, String OrgCode) {
		DBConnection dbcon=new DBConnection();
		Connection con=dbcon.getDBConnection();
		String name=null;
		try {
			PreparedStatement ps=con.prepareStatement("SELECT Emaiil FROM Doctor_Info WHERE ID=?  and OrgCode=? ");
			ps.setString(1, pid);
			ps.setString(2, OrgCode);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				name=rs.getString(1);
				//System.out.println(name);
			}
			con.close();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return name;
	}
	public String getDoctorIdByEmail(String pid, String OrgCode) {
		DBConnection dbcon=new DBConnection();
		Connection con=dbcon.getDBConnection();
		String ID=null;
		try {
			PreparedStatement ps=con.prepareStatement("SELECT ID FROM Doctor_Info WHERE Emaiil=? and OrgCode=? ");
			ps.setString(1, pid);
			ps.setString(2, OrgCode);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				ID=rs.getString(1);
				//System.out.println(name);
			}
			con.close();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ID;
	}
	public String searchDoctorRegNo(String pid, String OrgCode) {
		DBConnection dbcon=new DBConnection();
		Connection con=dbcon.getDBConnection();
		String name=null;
		try {
			PreparedStatement ps=con.prepareStatement("SELECT RegistrationNo FROM Doctor_Info WHERE ID=? and OrgCode=? ");
			ps.setString(1, pid);
			ps.setString(2, OrgCode);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				name=rs.getString(1);
			}
			con.close();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return name;
	}
	
	public String searchDoctorRegAuth(String pid, String OrgCode) {
		DBConnection dbcon=new DBConnection();
		Connection con=dbcon.getDBConnection();
		String name=null;
		try {
			PreparedStatement ps=con.prepareStatement("SELECT RegistrationAuthority FROM Doctor_Info WHERE ID=? and OrgCode=? ");
			ps.setString(1, pid);
			ps.setString(2, OrgCode);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				name=rs.getString(1);
			}
			con.close();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return name;
	}
	
	public int updateDoctor(DOCTOR_INFO DI) {
		DBConnection dbcon = new DBConnection();
		int pkey = 0;
		Connection con = dbcon.getDBConnection();
		String old_email=getDoctorEmailId(DI.getID(),DI.getOrgCode());
		try {

			
			PreparedStatement ps = con
					.prepareStatement("update Doctor_Info  set FirstName=?,	LastName=?,	Phone=?,	Emaiil=?,	Degree=?,	Specialization=?,	ExperienceSummary=?,	RegistrationNo=?,	RegistrationAuthority=?,LastUpdatedOn=?,	LastUpdatedBy=? WHERE ID=? and OrgCode=?"	);
			
			ps.setString(1, DI.getFirstName());
			ps.setString(2, DI.getLastName());
			ps.setString(3, DI.getPhone());
			ps.setString(4, DI.getEmaiil());
			ps.setString(5, DI.getDegree());
			ps.setString(6, DI.getSpecialization());
			ps.setString(7, DI.getExperienceSummary());
			ps.setString(8, DI.getRegistrationNo());
			ps.setString(9, DI.getRegistrationAuthority());

			ps.setDate(10, new java.sql.Date(DI.getLastUpdatedOn().getTime()));
			ps.setString(11, DI.getLastUpdatedBy());
			ps.setString(12, DI.getID());
			ps.setString(13, DI.getOrgCode());
			ps.executeUpdate();
			
			ps = con.prepareStatement("update login set email=? where email=? and Orgcode=?");
			ps.setString(1, DI.getEmaiil());
			ps.setString(2, old_email);
			ps.setString(3, DI.getOrgCode());

			pkey=ps.executeUpdate();
			
			con.close();
			
			
			return pkey;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pkey;
	}
	
	
}
