package com.pehrm.bean;

public class APPT_RQST {
	String RQST_ID;
	String name;
	String phone ;
	String email;
	String orgcode;
	String status;
	public APPT_RQST() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public APPT_RQST(String rQST_ID, String name, String phone, String email, String orgcode, String status) {
		super();
		RQST_ID = rQST_ID;
		this.name = name;
		this.phone = phone;
		this.email = email;
		this.orgcode = orgcode;
		this.status = status;
	}

	public String getRQST_ID() {
		return RQST_ID;
	}
	public void setRQST_ID(String rQST_ID) {
		RQST_ID = rQST_ID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getOrgcode() {
		return orgcode;
	}
	public void setOrgcode(String orgcode) {
		this.orgcode = orgcode;
	}
	
	
}
