package com.pehrm.bean;

public class ORGCODE {
	String Organization_name,	OrgCode;

	public ORGCODE() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ORGCODE(String organization_name, String orgCode) {
		super();
		Organization_name = organization_name;
		OrgCode = orgCode;
	}

	public String getOrganization_name() {
		return Organization_name;
	}

	public void setOrganization_name(String organization_name) {
		Organization_name = organization_name;
	}

	public String getOrgCode() {
		return OrgCode;
	}

	public void setOrgCode(String orgCode) {
		OrgCode = orgCode;
	}
	
	
	
	
}
