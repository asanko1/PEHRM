package com.pehrm.model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

//File Name SendEmail.java
import javax.mail.Message;
import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;

public class SendPrescription implements FilePath {

	public void sendPrescription(String pat_email, String pat_name, String pat_id, String pat_space_name) {
		try {
			FileInputStream ip = new FileInputStream(
					config_path + File.separator + "config" + File.separator + "config.properties");

			String from = "ABASAK";

			String host = "localhost";

			Properties prop = System.getProperties();
			Properties fileprop = System.getProperties();
			fileprop.load(ip);
			final String username = fileprop.getProperty("emailuser");
			final String password = fileprop.getProperty("emailpwd");
			prop.put("mail.smtp.host", "smtp.gmail.com");
			prop.put("mail.smtp.port", "587");
			prop.put("mail.smtp.auth", "true");
			prop.put("mail.smtp.starttls.enable", "true");

			Session session = Session.getInstance(prop, new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(username, password);
				}
			});
			

		
			MimeMessage message = new MimeMessage(session);

			message.setFrom(new InternetAddress(from, "DONOREPLY-MEDICIO"));

			message.addRecipient(Message.RecipientType.TO, new InternetAddress(pat_email));
			message.setSubject("Prescription for " + pat_space_name);

			// 3) create MimeBodyPart object and set your message text
			BodyPart messageBodyPart1 = new MimeBodyPart();
			messageBodyPart1.setText(
					"Dear Patient, \n Electronic copy of your prescription is enclosed with this email for your reference.\n"
					+ "Digital copy of this prescription is system generated and does not need any signature.");

			// 4) create new MimeBodyPart object and set DataHandler object to this object
			MimeBodyPart messageBodyPart2 = new MimeBodyPart();

			String filename = config_path + File.separator + "DocRepo" + File.separator + pat_id + File.separator
					+ pat_name + "_Prescription.pdf";// change accordingly
			DataSource source = new FileDataSource(filename);
			messageBodyPart2.setDataHandler(new DataHandler(source));
			messageBodyPart2.setFileName(pat_id + "_"
					+ pat_name + "_Prescription.pdf");

			// 5) create Multipart object and add MimeBodyPart objects to this object
			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(messageBodyPart1);
			multipart.addBodyPart(messageBodyPart2);

			// 6) set the multiplart object to the message object
			message.setContent(multipart);

			// 7) send message
			Transport.send(message);

			System.out.println("message sent....");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
