package com.pehrm.config;

import java.nio.file.Paths;

public class test {

	public static void main(String[] args) {
		 String userDirectory = Paths.get("")
	                .toAbsolutePath()
	                .toString();
	        System.out.println(userDirectory);
	        
	      

	}

}
