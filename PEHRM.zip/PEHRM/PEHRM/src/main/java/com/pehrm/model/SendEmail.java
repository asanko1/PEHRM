package com.pehrm.model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

//File Name SendEmail.java

import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;

import javax.activation.*;

public class SendEmail implements FilePath{

	public void sendmail(String to, String subject, String text) throws IOException {
		 //FileInputStream ip= new FileInputStream(System.getProperty("user.dir")+File.separator+"config"+File.separator+"config.properties");
		FileInputStream ip = new FileInputStream(config_path + File.separator				+ "config" + File.separator + "config.properties");
		

		String from = "ABASAK";

		String host = "localhost";

		Properties prop = System.getProperties();
		Properties fileprop = System.getProperties();
		fileprop.load(ip);
		final String username = fileprop.getProperty("emailuser");
		final String password = fileprop.getProperty("emailpwd");
		prop.put("mail.smtp.host", "smtp.gmail.com");
		prop.put("mail.smtp.port", "587");
		prop.put("mail.smtp.auth", "true");
		prop.put("mail.smtp.starttls.enable", "true");

		Session session = Session.getInstance(prop, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});

		try {

			MimeMessage message = new MimeMessage(session);

			message.setFrom(new InternetAddress(from,"DONOREPLY-MEDICIO"));

			message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));

			message.setSubject(subject);

			message.setText(text);

			Transport.send(message);
			System.out.println("Sent message successfully....");
		} catch (MessagingException mex) {
			mex.printStackTrace();
		}
	}
	
	public static void main (String s[])
			{
				try {
					new SendEmail().sendmail("suvrasarkar.it@gmail.com", "Test Subject", "Test Body");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
}