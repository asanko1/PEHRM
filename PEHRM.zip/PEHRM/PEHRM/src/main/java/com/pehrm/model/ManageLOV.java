package com.pehrm.model;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import com.pehrm.bean.ORGCODE;
import com.pehrm.bean.STATES;
import com.pehrm.config.DBConnection;

public class ManageLOV implements FilePath {
	STATES st;
	ArrayList<STATES> st_arr=new ArrayList<STATES>();
	ArrayList<ORGCODE> org_arr=new ArrayList<ORGCODE>();
	public ArrayList<STATES> getState() {
		DBConnection dbcon=new DBConnection();
		Connection con=dbcon.getDBConnection();
		Properties prop=new Properties(); 
		try {
		FileInputStream ip= new FileInputStream(config_path+File.separator+"config"+File.separator+"config.properties");
		prop.load(ip);
		
			PreparedStatement ps=con.prepareStatement("select statename from states WHERE country=? order by 1");
			ps.setString(1, prop.getProperty("Country"));
			ResultSet rs=ps.executeQuery();
			
			while(rs.next())  {
				st=new STATES(rs.getString(1),prop.getProperty("Country"));
				st_arr.add(st);
			}
			con.close();
		}
		
		catch(Exception e)
		{ System.out.println(e);}  
		
		return st_arr;
	}
	
	
	public ArrayList<ORGCODE> getOrgCodeList() {
		
		DBConnection dbcon=new DBConnection();
		ORGCODE org;
		Connection con=dbcon.getDBConnection();
		try {
			PreparedStatement ps=con.prepareStatement("select Organization_name, OrgCode from OrgCode_Master ");
			ResultSet rs=ps.executeQuery();
			
			while(rs.next())  {
				org=new ORGCODE();
				org.setOrganization_name(rs.getString(1));
				org.setOrgCode(rs.getString(2));
				
				org_arr.add(org);
			}
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return org_arr;
	}
}
