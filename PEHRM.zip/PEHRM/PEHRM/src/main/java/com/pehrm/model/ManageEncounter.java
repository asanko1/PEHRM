package com.pehrm.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.cj.jdbc.CallableStatement;
import com.pehrm.bean.ENCOUNTER_RCD;
import com.pehrm.config.DBConnection;

public class ManageEncounter {
	ENCOUNTER_RCD e;

	
	public ENCOUNTER_RCD getEncounterData(String PID, String OrgCode) {
		String s = null;
		e=new ENCOUNTER_RCD();
		DBConnection dbcon = new DBConnection();
		Connection con = dbcon.getDBConnection();
		try {
			PreparedStatement ps = con.prepareStatement("SELECT MedicalHistory, CurrentMedications,DrugAllergy FROM Patient_Addl_Info WHERE PID=?  and OrgCode=? ");
			ps.setString(1, PID);
			ps.setString(2, OrgCode);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				
				e.setMedicalHistory(rs.getString(1));
				e.setCurrentMedications(rs.getString(2));
				e.setDrugAllergy(rs.getString(3));
				}
			ps = con.prepareStatement("SELECT * FROM ENCOUNTER_RCD WHERE PID=? ORDER BY convert(SUBSTRING(EID,2),decimal) DESC, CreatedOn DESC");
			ps.setString(1, PID);
			rs=ps.executeQuery();
			while(rs.next()) {
				e.setEID(rs.getString(1));
				e.setPID(rs.getString(2));
				e.setDOC_ID(rs.getString(3));
				//System.out.println(rs.getString(3));
				e.setComplaints(rs.getString(4));
				e.setMeasurements(rs.getString(5));
				e.setAdvices(rs.getString(6));
				e.setLastUpdatedOn(rs.getDate(9));
				//System.out.println("val"+e.getComplaints()+" "+e.getAdvices());
				break;
			}
			con.close();
		}

		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return e;
	}
	
	public String saveEncounterData(ENCOUNTER_RCD en) {
		DBConnection dbcon = new DBConnection();
		Connection con = dbcon.getDBConnection();
		String pkey=null;
		try {
			PreparedStatement ps = con.prepareStatement("select count(*) from Patient_Addl_Info  WHERE PID=? ");
			ps.setString(1, en.getPID());
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				if(rs.getInt(1)==0) {
					ps = con.prepareStatement("insert into Patient_Addl_Info values (?,?,?,?,?,?,?,?,?)");
					ps.setString(1, en.getPID());
					ps.setString(2, en.getMedicalHistory());
					ps.setString(3, en.getCurrentMedications());
					ps.setString(4, en.getDrugAllergy());
					ps.setDate(5,  new java.sql.Date(en.getCreatedOn().getTime()));
					ps.setString(6,en.getCreatedBy());
					ps.setDate(7, new java.sql.Date(en.getLastUpdatedOn().getTime()));
					ps.setString(8,en.getLastUpdatedBy());
					ps.setString(9, en.getOrgCode());
					ps.executeUpdate();
				}else {
					ps = con.prepareStatement("update Patient_Addl_Info set MedicalHistory=?,CurrentMedications=?,DrugAllergy=?,LastUpdatedOn=?,LastUpdatedBy=? where PID=?");
					ps.setString(1, en.getMedicalHistory());
					ps.setString(2, en.getCurrentMedications());
					ps.setString(3, en.getDrugAllergy());
					ps.setDate(4, new java.sql.Date(en.getLastUpdatedOn().getTime()));
					ps.setString(5,en.getLastUpdatedBy());
					ps.setString(6, en.getPID());
					ps.executeUpdate();
				}
			}
			String query = "{CALL sp_get_pkey(?,?,?)}";
			CallableStatement stmt = (CallableStatement) con.prepareCall(query);
			stmt.setString(1, "ENCOUNTER_RCD");
			stmt.setString(2, "EID");
			stmt.registerOutParameter(3, java.sql.Types.VARCHAR);
			stmt.executeQuery();
			pkey=stmt.getString(3);
			en.setEID(pkey);
			//System.out.println(pkey);
			ps = con.prepareStatement("insert into ENCOUNTER_RCD values (?,?,?,?,?,?,?,?,?,?,?)");
			ps.setString(1, pkey);
			
			ps.setString(2, en.getPID());
			ps.setString(3, en.getDOC_ID());
			ps.setString(4, en.getComplaints());
			ps.setString(5, en.getMeasurements());
			ps.setString(6, en.getAdvices());
			ps.setDate(7,  new java.sql.Date(en.getCreatedOn().getTime()));
			ps.setString(8,en.getCreatedBy());
			ps.setDate(9, new java.sql.Date(en.getLastUpdatedOn().getTime()));
			ps.setString(10,en.getLastUpdatedBy());
			ps.setString(11, en.getOrgCode());
			ps.executeUpdate();
			
			con.close();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pkey;
		
	}
	
	public ArrayList<ENCOUNTER_RCD> getAllEncounterData(String PID, String OrgCode) {
		String s = null;
		e=new ENCOUNTER_RCD();
		DBConnection dbcon = new DBConnection();
		Connection con = dbcon.getDBConnection();
		ArrayList<ENCOUNTER_RCD> all_enc=new ArrayList<ENCOUNTER_RCD>();
		try {
			
			PreparedStatement ps = con.prepareStatement("SELECT * FROM ENCOUNTER_RCD WHERE PID=?  and OrgCode=? ORDER BY convert(SUBSTRING(EID,2),decimal) DESC, CreatedOn DESC");
			ps.setString(1, PID);
			ps.setString(2, OrgCode);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				
				e=new ENCOUNTER_RCD();
				e.setEID(rs.getString(1));
				e.setPID(rs.getString(2));
				e.setDOC_ID(rs.getString(3));
				e.setComplaints(rs.getString(4));
				e.setMeasurements(rs.getString(5));
				e.setAdvices(rs.getString(6));
				e.setLastUpdatedOn(rs.getDate(9));
				//System.out.println("val"+e.getComplaints()+" "+e.getAdvices());
				all_enc.add(e);
				
			}
			con.close();
		}

		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return  all_enc;
	}

}
