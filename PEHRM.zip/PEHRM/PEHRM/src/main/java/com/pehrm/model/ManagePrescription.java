package com.pehrm.model;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.pehrm.bean.ENCOUNTER_RCD;
import com.pehrm.config.DBConnection;

public class ManagePrescription implements FilePath {
	ENCOUNTER_RCD e;
	public void generatePrescription(String pat_id, String doc_id, String OrgCode)
	{
		String s = null;
		e=new ENCOUNTER_RCD();
		DBConnection dbcon = new DBConnection();
		Connection con = dbcon.getDBConnection();
		ArrayList<ENCOUNTER_RCD> all_enc=new ArrayList<ENCOUNTER_RCD>();
		try {
			
			PreparedStatement ps = con.prepareStatement("SELECT * FROM ENCOUNTER_RCD WHERE PID=? ORDER BY convert(SUBSTRING(EID,2),decimal) DESC, CreatedOn DESC");
			ps.setString(1, pat_id);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				
				e=new ENCOUNTER_RCD();
				e.setEID(rs.getString(1));
				e.setPID(rs.getString(2));
				e.setDOC_ID(rs.getString(3));
				e.setComplaints(rs.getString(4));
				e.setMeasurements(rs.getString(5));
				e.setAdvices(rs.getString(6));
				e.setLastUpdatedOn(rs.getDate(9));
				//System.out.println("val"+e.getComplaints()+" "+e.getAdvices());
				all_enc.add(e);
				
			}
			con.close();
		}

		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ManagePatient mp=new ManagePatient();
		String pat_name=mp.searchPatientNameWithouSpaceByPID(pat_id,OrgCode);
		String patname=mp.searchPatientByPID(pat_id,OrgCode);
		String pat_gen=mp.getPatientGender(pat_id,OrgCode);
		String pat_age=mp.getPatientAge(pat_id,OrgCode);
		Document document = new Document();
		try {
			String uploadpath=config_path+File.separator+"DocRepo"+File.separator+pat_id;
			File uploadDir = new File(uploadpath);
			if (!uploadDir.exists()) {
				uploadDir.mkdir();
			}
			PdfWriter.getInstance(document, new FileOutputStream(uploadpath+File.separator+pat_name+"_Prescription.pdf"));
			document.open();
			Font bold =  new Font(FontFamily.HELVETICA, 12, Font.BOLD);
			  document.add(new Paragraph("                   "));
		        document.add(new Paragraph("                   "));
		        document.add(new Paragraph("                   "));
		        document.add(new Paragraph("                   "));
			document.add(new Paragraph("*************************************************Prescription*************************************************"));
			 document.add(new Paragraph("                   "));
			 document.add(new Paragraph("PID: "+pat_id,bold));
			document.add(new Paragraph("Name: "+patname+"          Age: "+pat_age+"          Gender: "+pat_gen,bold));
			 document.add(new Paragraph("                   "));
		     document.add(new Paragraph("                   "));
			PdfPTable table = new PdfPTable(3);
			table.setWidthPercentage(100); //Width 100%
	        table.setSpacingBefore(10f); //Space before table
	        table.setSpacingAfter(10f); //Space after table
	        float[] columnWidths = {1f, 1f,2f};
	        table.setWidths(columnWidths);
	        
	        
	        PdfPCell cell1 = new PdfPCell(new Paragraph("Date",bold));
	        cell1.setBorderColor(BaseColor.BLACK);
	        cell1.setPaddingLeft(10);
	        
	        cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
	        cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
	        
	        PdfPCell cell2 = new PdfPCell(new Paragraph("Complaints",bold));
	        cell1.setBorderColor(BaseColor.BLACK);
	        cell1.setPaddingLeft(10);
	        cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
	        cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
	        
	        PdfPCell cell3 = new PdfPCell(new Paragraph("Advices",bold));
	        cell1.setBorderColor(BaseColor.BLACK);
	        cell1.setPaddingLeft(10);
	        cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
	        cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
	        
	        table.addCell(cell1);
	        table.addCell(cell2);
	        table.addCell(cell3);
	 
	        
			for(int i=0;i<all_enc.size();i++) {
				 cell1 = new PdfPCell(new Paragraph(String.valueOf(all_enc.get(i).getLastUpdatedOn())));
		        cell1.setBorderColor(BaseColor.BLACK);
		        cell1.setPaddingLeft(10);
		        cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
		        cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
		        
		        cell2 = new PdfPCell(new Paragraph(String.valueOf(all_enc.get(i).getComplaints())));
		        cell1.setBorderColor(BaseColor.BLACK);
		        cell1.setPaddingLeft(10);
		        cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
		        cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
		        
		       
		        cell3 = new PdfPCell(new Paragraph(String.valueOf(all_enc.get(i).getAdvices())));
		        cell1.setBorderColor(BaseColor.BLACK);
		        cell1.setPaddingLeft(10);
		        cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
		        cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
		        
		        table.addCell(cell1);
		        table.addCell(cell2);
		        table.addCell(cell3);
			}
			
	 
	        document.add(table);
	        ManageDoctor md=new ManageDoctor();
	        document.add(new Paragraph("                   "));
	        document.add(new Paragraph("                   "));
	        document.add(new Paragraph("                   "));
	        document.add(new Paragraph("                   "));
	        document.add(new Paragraph("Prepared By: Dr."+md.searchDoctorByID(doc_id,OrgCode)));
	        document.add(new Paragraph(md.searchDoctorRegAuth(doc_id,OrgCode)+"    "+   md.searchDoctorRegNo(doc_id,OrgCode)));
	        
	        document.close();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (DocumentException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		
	}
}
