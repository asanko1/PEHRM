package com.pehrm.controller;

import java.util.List;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.tomcat.util.http.fileupload.FileItem;
import org.apache.tomcat.util.http.fileupload.disk.DiskFileItemFactory;
import java.io.File;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileUploadException;

import org.apache.commons.fileupload.servlet.ServletFileUpload;
 

import com.pehrm.bean.APPNMNT;
import com.pehrm.bean.APPT_RQST;
import com.pehrm.bean.DOCTOR_INFO;
import com.pehrm.bean.ENCOUNTER_RCD;
import com.pehrm.bean.LOC_DTL;
import com.pehrm.bean.LOGIN;
import com.pehrm.bean.PATIENT_INFO;
import com.pehrm.bean.UploadDetail;
import com.pehrm.config.DBConnection;
import com.pehrm.model.FilePath;
import com.pehrm.model.ManageAppointment;
import com.pehrm.model.ManageDoctor;
import com.pehrm.model.ManageEncounter;
import com.pehrm.model.ManageLocation;
import com.pehrm.model.ManageLogin;
import com.pehrm.model.ManagePatient;
import com.pehrm.model.ManagePrescription;
import com.pehrm.model.SendEmail;

/**
 * Servlet implementation class ROUTEREQUEST
 */
public class ROUTEREQUEST extends HttpServlet implements FilePath {
	private static final long serialVersionUID = 1L;
	RequestDispatcher rd = null;
	HttpSession session = null;
	FileReader fr = null;
	BufferedReader br = null;
	ManagePatient mp = null;
	PATIENT_INFO pat = null;
	DOCTOR_INFO DI = null;
	ManageDoctor md = null;
	LOC_DTL l = null;
	ManageLocation ml = null;
	APPNMNT A = null;
	ManageAppointment ma = null;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ROUTEREQUEST() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
		if(request.getParameter("formname")!=null) {
			if(request.getParameter("formname").equals("resolveaptrqst")) {
				ManageAppointment ma=new ManageAppointment();
				int c=ma.updateAppointmentRequest(request.getParameter("rqst_id"), session.getAttribute("ccode").toString());
				if(c>0) {
					rd = request.getRequestDispatcher("ViewAppointmentRequests.jsp?orgcode="+session.getAttribute("ccode").toString());
					rd.forward(request, response);
					
				}
			}else if(request.getParameter("formname").equals("logout"))  {
				session.invalidate();
				session = request.getSession(false);
				rd = request.getRequestDispatcher("/Logout.jsp");
				rd.forward(request, response);
			}else if(request.getParameter("formname").equals("viewenc"))  {
				doPost(request,response);
			}else if(request.getParameter("formname").equals("viewallenc"))  {
				doPost(request,response);
			}
			
		}else {
				doPost(request,response);
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		if (request.getParameter("formname") != null) {
			if (request.getParameter("formname").equals("login")) {

				ManageLogin ml = new ManageLogin();

				LOGIN lg = ml.checkLogin(request.getParameter("email"), request.getParameter("password"),
						request.getParameter("companycode"));

				if (lg.getName() == null) {
					rd = request.getRequestDispatcher("/login.jsp?error=1");
					rd.forward(request, response);
				} else {
					session = request.getSession();
					session.setAttribute("name", lg.getName());
					session.setAttribute("ccode", lg.getCcode());
					session.setAttribute("email", lg.getEmail());
					session.setAttribute("last_login", lg.getLast_login());
					session.setAttribute("usertype", lg.getUsertype());
					rd = request.getRequestDispatcher("/Homepage.jsp");
					rd.forward(request, response);
				}
			}else if (request.getParameter("formname").equals("appo_req")) {
				APPT_RQST ar=new APPT_RQST();
				ar.setName(request.getParameter("first_name")+" "+request.getParameter("last_name"));
				ar.setPhone(request.getParameter("phone"));
				ar.setEmail(request.getParameter("email"));
				ar.setOrgcode(request.getParameter("clinic"));
				ar.setStatus("New");
				
				ManageAppointment ma=new ManageAppointment();
				String pkey=ma.saveAppointmentRequest(ar);
				if (pkey != null) {
					rd = request.getRequestDispatcher("/index.jsp?appt=" + pkey);
					rd.forward(request, response);	
				}
				
			}
			else if (request.getParameter("formname").equals("createpat")) {
				pat = new PATIENT_INFO();
				pat.setFirstName(request.getParameter("fname").trim());
				pat.setLastName(request.getParameter("lname").trim());
				pat.setEmaiil(request.getParameter("email").trim());
				pat.setPhone(request.getParameter("phone").trim());
				String dob = request.getParameter("dob");
				// System.out.println(dob);
				if (dob != null) {
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
					Date dob_d = null;
					try {
						dob_d = sdf.parse(dob);
						// System.out.println(dob_d);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace(); session.invalidate(); session = request.getSession(false); response.sendRedirect("Errorpage.jsp"); session.invalidate(); session = request.getSession(false); response.sendRedirect("Errorpage.jsp");
					}
					if (dob_d != null) {
						pat.setDOB(dob_d);
						pat.setAge(String.valueOf((new java.util.Date().getYear() - dob_d.getYear())));
					} else {
						pat.setDOB(null);
						pat.setAge(request.getParameter("age").trim());
					}
				} else {
					pat.setDOB(null);
					pat.setAge(request.getParameter("age").trim());
				}
				pat.setAddressLine1(request.getParameter("addr1").trim());
				pat.setAddressLine2(request.getParameter("addr2").trim());
				pat.setCity(request.getParameter("city").trim());
				pat.setState(request.getParameter("state").trim());
				pat.setPIN(request.getParameter("pin").trim());
				pat.setOrgCode(request.getParameter("orgcode").trim());
				pat.setCreatedBy(session.getAttribute("name").toString());
				pat.setLastUpdatedBy(session.getAttribute("name").toString());
				pat.setGender(request.getParameter("gender").trim());
				pat.setCreatedOn(new java.util.Date());
				pat.setLastUpdatedOn(new java.util.Date());
				mp = new ManagePatient();
				String pkey = mp.createPatient(pat);
				if (pkey != null) {
					String w = request.getParameter("welcome");
					String s = null;
					if (w != null) {
						if (w.equals("true")) {
							// fr=new FileReader(new
							// File(System.getProperty("user.dir")+File.separator+"config"+File.separator+"Welcome_Subject.txt"));
							fr = new FileReader(new File(
									config_path + File.separator + "config" + File.separator + "Welcome_Subject.txt"));
							br = new BufferedReader(fr);
							String Subject = null;
							while ((s = br.readLine()) != null) {
								Subject = s;

							}
							String Text = "";
							// fr=new FileReader(new
							// File(System.getProperty("user.dir")+File.separator+"config"+File.separator+"Welcome_Mail.txt"));
							fr = new FileReader(new File(
									config_path + File.separator + "config" + File.separator + "Welcome_Mail.txt"));
							br = new BufferedReader(fr);
							while ((s = br.readLine()) != null) {
								Text = Text + "\n" + s;

							}
							String email = request.getParameter("email");
							SendEmail send = new SendEmail();
							send.sendmail(email, Subject, Text);

						}
					}
					rd = request.getRequestDispatcher("/Homepage.jsp?pid=" + pkey);
					rd.forward(request, response);
				}

			} else if (request.getParameter("formname").equals("updatepat")) {
				pat = new PATIENT_INFO();
				pat.setPID(request.getParameter("pat_id").trim());
				pat.setFirstName(request.getParameter("fname").trim());
				pat.setLastName(request.getParameter("lname").trim());
				pat.setEmaiil(request.getParameter("email").trim());
				pat.setPhone(request.getParameter("phone").trim());
				String dob = request.getParameter("dob");
				// System.out.println(dob);
				if (dob != null) {
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
					Date dob_d = null;
					try {
						dob_d = sdf.parse(dob);
						// System.out.println(dob_d);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace(); session.invalidate(); session = request.getSession(false); response.sendRedirect("Errorpage.jsp");
					}
					if (dob_d != null) {
						pat.setDOB(dob_d);
						pat.setAge(String.valueOf((new java.util.Date().getYear() - dob_d.getYear())));
					} else {
						pat.setDOB(null);
						pat.setAge(request.getParameter("age").trim());
					}
				} else {
					pat.setDOB(null);
					pat.setAge(request.getParameter("age").trim());
				}
				pat.setAddressLine1(request.getParameter("addr1").trim());
				pat.setAddressLine2(request.getParameter("addr2").trim());
				pat.setCity(request.getParameter("city").trim());
				pat.setState(request.getParameter("state").trim());
				pat.setPIN(request.getParameter("pin").trim());
				
				
				pat.setLastUpdatedBy(session.getAttribute("name").toString());
				pat.setGender(request.getParameter("gender").trim());
				
				pat.setLastUpdatedOn(new java.util.Date());
				mp = new ManagePatient();
				int c = mp.updatePatient(pat,session.getAttribute("ccode").toString());
				if(c==1) {
					
					rd = request.getRequestDispatcher("/Homepage.jsp?pidu=" + request.getParameter("pat_id").trim());
					rd.forward(request, response);
				}

			} else if (request.getParameter("formname").equals("searchpat")) {
				String p = request.getParameter("phone").trim();
				// System.out.println("Here1");
				mp = new ManagePatient();
				ArrayList<PATIENT_INFO> pat_arr = mp.searchPatient(p,session.getAttribute("ccode").toString());
				// System.out.println(pat_arr);
				if (pat_arr != null) {
					if (pat_arr.size() > 0) {
						request.setAttribute("patsrchres", pat_arr);
						// System.out.println("here2");
						rd = request.getRequestDispatcher("/SearchPatient.jsp?patsrch=true");
						rd.forward(request, response);
					} else {
						// System.out.println("here3");
						rd = request.getRequestDispatcher("/SearchPatient.jsp?patsrch=false");
						rd.forward(request, response);
					}
				} else {
					// System.out.println("here3");
					rd = request.getRequestDispatcher("/SearchPatient.jsp?patsrch=false");
					rd.forward(request, response);
				}

			} else if (request.getParameter("formname").equals("createdoc")) {
				DI = new DOCTOR_INFO();
				DI.setFirstName(request.getParameter("fname").trim());
				DI.setLastName(request.getParameter("lname").trim());
				DI.setEmaiil(request.getParameter("email").trim());
				DI.setPhone(request.getParameter("phone").trim());
				DI.setDegree(request.getParameter("dgre").trim());
				DI.setSpecialization(request.getParameter("spcl").trim());
				DI.setExperienceSummary(request.getParameter("summary").trim());
				DI.setRegistrationAuthority(request.getParameter("regauth").trim());
				DI.setRegistrationNo(request.getParameter("regno").trim());
				DI.setOrgCode(request.getParameter("orgcode").trim());
				DI.setCreatedBy(session.getAttribute("name").toString());
				DI.setLastUpdatedBy(session.getAttribute("name").toString());
				DI.setCreatedOn(new java.util.Date());
				DI.setLastUpdatedOn(new java.util.Date());
				ManageDoctor mp = new ManageDoctor();
				String pkey = mp.createDoctor(DI);
				if (pkey != null) {

					String s = null;

					// fr=new FileReader(new
					// File(System.getProperty("user.dir")+File.separator+"config"+File.separator+"Welcome_Subject.txt"));
					fr = new FileReader(
							new File(config_path + File.separator + "config" + File.separator + "Welcome_Subject.txt"));
					br = new BufferedReader(fr);
					String Subject = null;
					while ((s = br.readLine()) != null) {
						Subject = s;

					}
					String Text = "";
					// fr=new FileReader(new
					// File(System.getProperty("user.dir")+File.separator+"config"+File.separator+"Welcome_Mail.txt"));
					fr = new FileReader(new File(
							config_path + File.separator + "config" + File.separator + "Welcome_Mail_Doc.txt"));
					br = new BufferedReader(fr);
					while ((s = br.readLine()) != null) {
						Text = Text + "\n" + s;

					}
					String email = request.getParameter("email");
					SendEmail send = new SendEmail();
					send.sendmail(email, Subject, Text);

					rd = request.getRequestDispatcher("/Homepage.jsp?did=" + pkey);
					rd.forward(request, response);
				}

			}else if (request.getParameter("formname").equals("updatedoc")) {
				DI = new DOCTOR_INFO();
				DI.setID(request.getParameter("did").trim());
				DI.setFirstName(request.getParameter("fname").trim());
				DI.setLastName(request.getParameter("lname").trim());
				DI.setEmaiil(request.getParameter("email").trim());
				DI.setPhone(request.getParameter("phone").trim());
				DI.setDegree(request.getParameter("dgre").trim());
				DI.setSpecialization(request.getParameter("spcl").trim());
				DI.setExperienceSummary(request.getParameter("summary").trim());
				DI.setRegistrationAuthority(request.getParameter("regauth").trim());
				DI.setRegistrationNo(request.getParameter("regno").trim());
				DI.setOrgCode(request.getParameter("orgcode").trim());
				
				DI.setLastUpdatedBy(session.getAttribute("name").toString());
				
				DI.setLastUpdatedOn(new java.util.Date());
				ManageDoctor mp = new ManageDoctor();
				int pkey = mp.updateDoctor(DI);
				if (pkey != 0) {

					rd = request.getRequestDispatcher("/Homepage.jsp?didup=" + request.getParameter("did"));
					rd.forward(request, response);
				}

			}

			else if (request.getParameter("formname").equals("searchdoc")) {
				String p = request.getParameter("phone").trim();
				// System.out.println("Here1");
				md = new ManageDoctor();
				ArrayList<DOCTOR_INFO> doc_arr = md.searchDoctor(p,session.getAttribute("ccode").toString());
				// System.out.println(doc_arr);
				if (doc_arr != null) {
					if (doc_arr.size() > 0) {
						request.setAttribute("docsrchres", doc_arr);
						// System.out.println("here2");
						rd = request.getRequestDispatcher("/SearchDoctor.jsp?docsrch=true");
						rd.forward(request, response);
					} else {
						// System.out.println("here3");
						rd = request.getRequestDispatcher("/SearchDoctor.jsp?docsrch=false");
						rd.forward(request, response);
					}
				} else {
					// System.out.println("here3");
					rd = request.getRequestDispatcher("/SearchDoctor.jsp?docsrch=false");
					rd.forward(request, response);
				}

			} else if (request.getParameter("formname").equals("createloc")) {
				l = new LOC_DTL();
				l.setLOC_NM(request.getParameter("lname"));
				l.setEmail(request.getParameter("email"));
				l.setPhone1(request.getParameter("phone"));
				l.setAddressLine1(request.getParameter("addr1").trim());
				l.setAddressLine2(request.getParameter("addr2").trim());
				l.setCity(request.getParameter("city").trim());
				l.setState(request.getParameter("state").trim());
				l.setPIN(request.getParameter("pin").trim());
				l.setOrgCode(request.getParameter("orgcode").trim());
				l.setCreatedBy(session.getAttribute("name").toString());
				l.setLastUpdatedBy(session.getAttribute("name").toString());
				l.setCreatedOn(new java.util.Date());
				l.setLastUpdatedOn(new java.util.Date());
				l.setPhone2(request.getParameter("alter_phone"));
				ml = new ManageLocation();
				String pkey = ml.createLocation(l);
				if (pkey != null) {
					rd = request.getRequestDispatcher("/Homepage.jsp?lid=" + pkey);
					rd.forward(request, response);
				}
			} else if (request.getParameter("formname").equals("createapp")) {
				A = new APPNMNT();
				A.setPID(request.getParameter("patid"));
				String doa = request.getParameter("apt_date");
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				Date doa_o = null;
				try {
					doa_o = sdf.parse(doa);

				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace(); session.invalidate(); session = request.getSession(false); response.sendRedirect("Errorpage.jsp");
				}
				A.setADate(doa_o);
				A.setHour(request.getParameter("hr"));
				A.setMin(request.getParameter("min"));
				A.setDn(request.getParameter("dn"));
				A.setPOV(request.getParameter("pov"));
				A.setLOC_ID(request.getParameter("ven"));
				A.setDOC_ID(request.getParameter("doc"));
				if (request.getParameter("emg") != null) {
					A.setEmergency_ind(request.getParameter("emg"));
				} else {
					A.setEmergency_ind("no");
				}
				A.setBookingMODE(request.getParameter("book"));
				A.setPAY_MODE(request.getParameter("pay"));
				A.setCreatedBy(session.getAttribute("name").toString());
				A.setLastUpdatedBy(session.getAttribute("name").toString());
				A.setCreatedOn(new java.util.Date());
				A.setLastUpdatedOn(new java.util.Date());
				A.setOrgCode(session.getAttribute("ccode").toString());
				ma = new ManageAppointment();
				String pkey = ma.createAppointment(A);
				if (pkey != null) {

					String s = null, s1 = null;

					// fr=new FileReader(new
					// File(System.getProperty("user.dir")+File.separator+"config"+File.separator+"Welcome_Subject.txt"));
					fr = new FileReader(new File(
							config_path + File.separator + "config" + File.separator + "Appointment_Subject.txt"));
					br = new BufferedReader(fr);
					String Subject = null;
					while ((s = br.readLine()) != null) {
						Subject = s;

					}
					String Text = "";
					// fr=new FileReader(new
					// File(System.getProperty("user.dir")+File.separator+"config"+File.separator+"Welcome_Mail.txt"));

					ManageDoctor md = new ManageDoctor();
					String docemail = md.getDoctorEmailId(A.getDOC_ID(),session.getAttribute("ccode").toString());
					String docname = md.searchDoctorByID(A.getDOC_ID(),session.getAttribute("ccode").toString());
					String time = A.getADate().toGMTString().substring(0, 11) + " " + A.getHour() + ":" + A.getMin()
							+ ":" + A.getDn();
					SendEmail send = new SendEmail();
					fr = new FileReader(new File(config_path + File.separator + "config" + File.separator
							+ "AppointmentNotification_Doctor.txt"));
					br = new BufferedReader(fr);
					while ((s = br.readLine()) != null) {
						s1 = s.replace("XXXXXXXX", docname);
						s1 = s1.replace("TTTTTTTTTT", time);

						Text = Text + "\n" + s1;

					}
					// System.out.println(docemail);
					send.sendmail(docemail, Subject, Text);

					Text = "";
					// fr=new FileReader(new
					// File(System.getProperty("user.dir")+File.separator+"config"+File.separator+"Welcome_Mail.txt"));

					ManagePatient mp = new ManagePatient();
					String patemail = mp.getPatientEmailId(A.getPID(),session.getAttribute("ccode").toString());
					String patname = mp.searchPatientByPID(A.getPID(),session.getAttribute("ccode").toString());
					time = A.getADate().toGMTString().substring(0, 11) + " " + A.getHour() + ":" + A.getMin() + ":"
							+ A.getDn();
					send = new SendEmail();

					fr = new FileReader(new File(config_path + File.separator + "config" + File.separator
							+ "AppointmentNotification_Patient.txt"));
					br = new BufferedReader(fr);
					while ((s = br.readLine()) != null) {
						s = s.replace("XXXXXXXX", patname);
						s = s.replace("TTTTTTTTTT", time);
						s = s.replace("DDDDDDDDDD", docname);
						// System.out.println(s);
						Text = Text + "\n" + s;

					}

					send.sendmail(patemail, Subject, Text);
					rd = request.getRequestDispatcher("/Homepage.jsp?aid=" + pkey);
					rd.forward(request, response);
				}

			} else if (request.getParameter("formname").equals("searchappt")) {

				String from_date = request.getParameter("from_date");
				String to_date = request.getParameter("to_date");
				String futuredate = "4000-01-01";
				Date fd = null, td = null;
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				SimpleDateFormat todateFormat = new SimpleDateFormat("yyyy-MM-dd");
				try {
					if (from_date.trim() == "") {
						fd = new java.util.Date();
					} else {

						fd = dateFormat.parse(from_date);

					}
					if (to_date.trim() == "") {
						td = dateFormat.parse(futuredate);
					} else {
						try {
							td = dateFormat.parse(to_date);
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace(); session.invalidate(); session = request.getSession(false); response.sendRedirect("Errorpage.jsp");
						}
					}
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace(); session.invalidate(); session = request.getSession(false); response.sendRedirect("Errorpage.jsp");
				}
				ArrayList<APPNMNT> ap_arr = new ArrayList<APPNMNT>();
				ManageAppointment ma = new ManageAppointment();
				ap_arr = ma.searchAppointment(session.getAttribute("ccode").toString(), fd, td);
				request.setAttribute("appsrches", ap_arr);

				rd = request.getRequestDispatcher("/ViewAllAppointments.jsp?appsrch=true");
				rd.forward(request, response);
			} else if (request.getParameter("formname").equals("updateapp")) {
				A = new APPNMNT();
				A.setAPPT_ID(request.getParameter("appt_id"));
				A.setPID(request.getParameter("patid"));
				String doa = request.getParameter("apt_date");
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				Date doa_o = null;
				try {
					doa_o = sdf.parse(doa);

				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace(); session.invalidate(); session = request.getSession(false); response.sendRedirect("Errorpage.jsp");
				}
				A.setADate(doa_o);
				A.setHour(request.getParameter("hr"));
				A.setMin(request.getParameter("min"));
				A.setDn(request.getParameter("dn"));
				A.setPOV(request.getParameter("pov"));
				A.setLOC_ID(request.getParameter("ven"));
				A.setDOC_ID(request.getParameter("doc"));
				if (request.getParameter("emg") != null) {
					A.setEmergency_ind(request.getParameter("emg"));
				} else {
					A.setEmergency_ind("no");
				}
				A.setBookingMODE(request.getParameter("book"));
				A.setPAY_MODE(request.getParameter("pay"));
				A.setCreatedBy(session.getAttribute("name").toString());
				A.setLastUpdatedBy(session.getAttribute("name").toString());
				A.setCreatedOn(new java.util.Date());
				A.setLastUpdatedOn(new java.util.Date());
				A.setOrgCode(session.getAttribute("ccode").toString());
				ma = new ManageAppointment();
				String pkey = ma.updateAppointment(A,session.getAttribute("ccode").toString());
				if (pkey != null) {
					String s = null, s1 = null;

					// fr=new FileReader(new
					// File(System.getProperty("user.dir")+File.separator+"config"+File.separator+"Welcome_Subject.txt"));
					fr = new FileReader(new File(
							config_path + File.separator + "config" + File.separator + "Appointment_Subject.txt"));
					br = new BufferedReader(fr);
					String Subject = null;
					while ((s = br.readLine()) != null) {
						Subject = s;

					}
					String Text = "";
					// fr=new FileReader(new
					// File(System.getProperty("user.dir")+File.separator+"config"+File.separator+"Welcome_Mail.txt"));

					ManageDoctor md = new ManageDoctor();
					String docemail = md.getDoctorEmailId(A.getDOC_ID(),session.getAttribute("ccode").toString());
					String docname = md.searchDoctorByID(A.getDOC_ID(),session.getAttribute("ccode").toString());
					String time = A.getADate().toGMTString().substring(0, 11) + " " + A.getHour() + ":" + A.getMin()
							+ ":" + A.getDn();
					SendEmail send = new SendEmail();
					fr = new FileReader(new File(config_path + File.separator + "config" + File.separator
							+ "AppointmentNotification_Doctor.txt"));
					br = new BufferedReader(fr);
					while ((s = br.readLine()) != null) {
						s1 = s.replace("XXXXXXXX", docname);
						s1 = s1.replace("TTTTTTTTTT", time);

						Text = Text + "\n" + s1;

					}
					// System.out.println(docemail);
					send.sendmail(docemail, Subject, Text);

					Text = "";
					// fr=new FileReader(new
					// File(System.getProperty("user.dir")+File.separator+"config"+File.separator+"Welcome_Mail.txt"));

					ManagePatient mp = new ManagePatient();
					String patemail = mp.getPatientEmailId(A.getPID(),session.getAttribute("ccode").toString());
					String patname = mp.searchPatientByPID(A.getPID(),session.getAttribute("ccode").toString());
					time = A.getADate().toGMTString().substring(0, 11) + " " + A.getHour() + ":" + A.getMin() + ":"
							+ A.getDn();
					send = new SendEmail();

					fr = new FileReader(new File(config_path + File.separator + "config" + File.separator
							+ "AppointmentNotification_Patient.txt"));
					br = new BufferedReader(fr);
					while ((s = br.readLine()) != null) {
						s = s.replace("XXXXXXXX", patname);
						s = s.replace("TTTTTTTTTT", time);
						s = s.replace("DDDDDDDDDD", docname);
						// System.out.println(s);
						Text = Text + "\n" + s;

					}

					send.sendmail(patemail, Subject, Text);
					rd = request.getRequestDispatcher("/Homepage.jsp?aidu=" + pkey);
					rd.forward(request, response);
				}

			} else if (request.getParameter("formname").equals("viewenc")) {
				String pat_id = request.getParameter("pat_id");
				String usertype = request.getParameter("usertype");
				ManagePatient mp = new ManagePatient();
				ENCOUNTER_RCD en = new ENCOUNTER_RCD();
				md = new ManageDoctor();

				ManageEncounter me = new ManageEncounter();
				en = me.getEncounterData(pat_id,session.getAttribute("ccode").toString());
				if (me != null) {
					String pat_name = mp.searchPatientByPID(pat_id,session.getAttribute("ccode").toString());

					// String doc_id = md.getDoctorIdByEmail(en.getDOC_ID());
					// System.out.print(doc_id);
					String doc_name = md.searchDoctorByID(en.getDOC_ID(),session.getAttribute("ccode").toString());
					String doc_regno = md.searchDoctorRegNo(en.getDOC_ID(),session.getAttribute("ccode").toString());
					en.setPID(pat_id);
					en.setPat_name(pat_name);
					en.setDoc_name(doc_name);
					en.setDoc_reg_no(doc_regno);
					en.setUsertype(usertype);
					session.setAttribute("en_temp", en);
					
					
					String docpath=config_path + File.separator + "DocRepo" + File.separator + pat_id;
					File fileUploadDirectory = new File(docpath);
					System.out.println(docpath);
					if (fileUploadDirectory.exists()) {
						//System.out.println(docpath);
						UploadDetail details = null;
				        File[] allFiles = fileUploadDirectory.listFiles();
				        List<UploadDetail> fileList = new ArrayList<UploadDetail>();  
				        
				        for (File file : allFiles) {
				        	//System.out.println("here");
				            details = new UploadDetail();
				            details.setFileName(file.getName());
				           // System.out.println(details.getFileName());
				            details.setFileSize(file.length() / 1024);
				            fileList.add(details);
				        }
				        
				        request.setAttribute("uploadedFiles", fileList);
					}
					rd = request.getRequestDispatcher("/ManageEncounter.jsp");
					rd.forward(request, response);
				}
			} else if (request.getParameter("formname").equals("saveenc")) {
				ManagePatient mp=new ManagePatient();
				String pat_id = request.getParameter("pat_id");
				String pat_name = mp.searchPatientByPID(pat_id,session.getAttribute("ccode").toString());
				String doc_id = md.getDoctorIdByEmail(session.getAttribute("email").toString(),session.getAttribute("ccode").toString());
				String doc_name = md.searchDoctorByID(doc_id,session.getAttribute("ccode").toString());
				String doc_regno = md.searchDoctorRegNo(doc_id,session.getAttribute("ccode").toString());
				ENCOUNTER_RCD en = new ENCOUNTER_RCD();
				en.setPID(pat_id);
				en.setMedicalHistory(request.getParameter("med_hist"));
				en.setCurrentMedications(request.getParameter("curr_med"));
				String f = null;

				en.setDrugAllergy(request.getParameter("drug_all"));

				String txt = request.getParameter("measure");
				int last = txt.lastIndexOf("---------------------");
				if (last == -1) {
					en.setMeasurements(request.getParameter("measure"));
				} else {
					f = txt.substring(last + 21);
					en.setMeasurements(f);
				}

				txt = request.getParameter("comp");
				last = txt.lastIndexOf("---------------------");
				if (last == -1) {
					en.setComplaints(request.getParameter("comp"));
				} else {
					f = txt.substring(last + 21);
					en.setComplaints(f);
				}

				txt = request.getParameter("advice");
				last = txt.lastIndexOf("---------------------");
				if (last == -1) {
					en.setAdvices(request.getParameter("advice"));
				} else {
					f = txt.substring(last + 21);
					en.setAdvices(f);
				}

				ManageDoctor md = new ManageDoctor();
				en.setDOC_ID(md.getDoctorIdByEmail(session.getAttribute("email").toString(),session.getAttribute("ccode").toString()));
				en.setCreatedBy(session.getAttribute("name").toString());
				en.setLastUpdatedBy(session.getAttribute("name").toString());
				en.setCreatedOn(new java.util.Date());
				en.setLastUpdatedOn(new java.util.Date());
				en.setOrgCode(session.getAttribute("ccode").toString());
				 mp = new ManagePatient();

				en.setPat_name(pat_name);
				en.setDoc_name(doc_name);
				en.setDoc_reg_no(doc_regno);
				ManageEncounter me = new ManageEncounter();
				String pkey = me.saveEncounterData(en);
				if (pkey != null) {
					ENCOUNTER_RCD en_rcd = me.getEncounterData(pat_id,session.getAttribute("ccode").toString());
					en_rcd.setPat_name(pat_name);
					en_rcd.setDoc_name(doc_name);
					en_rcd.setDoc_reg_no(doc_regno);
					en_rcd.setUsertype(session.getAttribute("usertype").toString());
					session.setAttribute("en_temp", en_rcd);
					ManagePrescription mpe=new ManagePrescription();
					mpe.generatePrescription(pat_id,doc_id,session.getAttribute("ccode").toString());
					String docpath=config_path + File.separator + "DocRepo" + File.separator + pat_id;
					File fileUploadDirectory = new File(docpath);
					System.out.println(docpath);
					if (fileUploadDirectory.exists()) {
						//System.out.println(docpath);
						UploadDetail details = null;
				        File[] allFiles = fileUploadDirectory.listFiles();
				        List<UploadDetail> fileList = new ArrayList<UploadDetail>();  
				        
				        for (File file : allFiles) {
				        	//System.out.println("here");
				            details = new UploadDetail();
				            details.setFileName(file.getName());
				            //System.out.println(details.getFileName());
				            details.setFileSize(file.length() / 1024);
				            fileList.add(details);
				        }
				        
				        request.setAttribute("uploadedFiles", fileList);
					}
					rd = request.getRequestDispatcher("/ManageEncounter.jsp");
					rd.forward(request, response);
				}

			} else if (request.getParameter("formname").equals("viewallenc")) {
				String pat_id = request.getParameter("pat_id");

				ManagePatient mp = new ManagePatient();
				// ENCOUNTER_RCD en=new ENCOUNTER_RCD();
				md = new ManageDoctor();
				ArrayList<ENCOUNTER_RCD> all_enc = new ArrayList<ENCOUNTER_RCD>();
				ManageEncounter me = new ManageEncounter();
				all_enc = me.getAllEncounterData(pat_id,session.getAttribute("ccode").toString());
				if (me != null) {
					String pat_name = mp.searchPatientByPID(pat_id,session.getAttribute("ccode").toString());

					for (int i = 0; i < all_enc.size(); i++) {
						// String doc_id = md.getDoctorIdByEmail(all_enc.get(i).getDOC_ID());
						String doc_name = md.searchDoctorByID(all_enc.get(i).getDOC_ID(),session.getAttribute("ccode").toString());
						String doc_regno = md.searchDoctorRegNo(all_enc.get(i).getDOC_ID(),session.getAttribute("ccode").toString());
						// System.out.println("Here1"+all_enc.get(i).getMeasurements()+all_enc.get(i).getAdvices());
						all_enc.get(i).setPID(pat_id);
						all_enc.get(i).setPat_name(pat_name);
						all_enc.get(i).setDoc_name(doc_name);
						all_enc.get(i).setDoc_reg_no(doc_regno);
					}
					session.setAttribute("en_list", all_enc);
					rd = request.getRequestDispatcher("/ViewEncounterHistory.jsp");
					rd.forward(request, response);
				}
			}else if (request.getParameter("formname").equals("uploaddoc")) {
				
			}
			else if (request.getParameter("formname").equals("logout")) {
				session.invalidate();
				session = request.getSession(false);
				rd = request.getRequestDispatcher("/Logout.jsp");
				rd.forward(request, response);
			} 
			
		} else if (request.getParameter("formname") == null) {
			System.out.println(request.getParameter("docupload"));
			ml = new ManageLocation();
			ArrayList<LOC_DTL> loc_arr = new ArrayList<LOC_DTL>();
			// System.out.println(session.getAttribute("ccode"));
			loc_arr = ml.getAllLocations(session.getAttribute("ccode").toString());
			request.setAttribute("loc_res", loc_arr);
			rd = request.getRequestDispatcher("/GetAllLocations.jsp");
			rd.forward(request, response);
		}

	}

}
