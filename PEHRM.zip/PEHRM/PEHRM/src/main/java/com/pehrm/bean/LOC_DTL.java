package com.pehrm.bean;

import java.util.Date;

public class LOC_DTL {
	String	LOC_ID	;
	String	LOC_NM	;
	String	AddressLine1	;
	String	AddressLine2	;
	String	City	;
	String	State	;
	String	PIN	;
	String	Phone1	;
	String	Phone2	;
	String	Email	;
	Date	CreatedOn	;
	String	CreatedBy	;
	Date	LastUpdatedOn	;
	String	LastUpdatedBy	;
	String	OrgCode	;
	public LOC_DTL() {
		super();
		// TODO Auto-generated constructor stub
	}
	public LOC_DTL(String lOC_ID, String lOC_NM, String addressLine1, String addressLine2, String city, String state,
			String pIN, String phone1, String phone2, String email, Date createdOn, String createdBy,
			Date lastUpdatedOn, String lastUpdatedBy, String orgCode) {
		super();
		LOC_ID = lOC_ID;
		LOC_NM = lOC_NM;
		AddressLine1 = addressLine1;
		AddressLine2 = addressLine2;
		City = city;
		State = state;
		PIN = pIN;
		Phone1 = phone1;
		Phone2 = phone2;
		Email = email;
		CreatedOn = createdOn;
		CreatedBy = createdBy;
		LastUpdatedOn = lastUpdatedOn;
		LastUpdatedBy = lastUpdatedBy;
		OrgCode = orgCode;
	}
	public String getLOC_ID() {
		return LOC_ID;
	}
	public void setLOC_ID(String lOC_ID) {
		LOC_ID = lOC_ID;
	}
	public String getLOC_NM() {
		return LOC_NM;
	}
	public void setLOC_NM(String lOC_NM) {
		LOC_NM = lOC_NM;
	}
	public String getAddressLine1() {
		return AddressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		AddressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return AddressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		AddressLine2 = addressLine2;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getPIN() {
		return PIN;
	}
	public void setPIN(String pIN) {
		PIN = pIN;
	}
	public String getPhone1() {
		return Phone1;
	}
	public void setPhone1(String phone1) {
		Phone1 = phone1;
	}
	public String getPhone2() {
		return Phone2;
	}
	public void setPhone2(String phone2) {
		Phone2 = phone2;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public Date getCreatedOn() {
		return CreatedOn;
	}
	public void setCreatedOn(Date createdOn) {
		CreatedOn = createdOn;
	}
	public String getCreatedBy() {
		return CreatedBy;
	}
	public void setCreatedBy(String createdBy) {
		CreatedBy = createdBy;
	}
	public Date getLastUpdatedOn() {
		return LastUpdatedOn;
	}
	public void setLastUpdatedOn(Date lastUpdatedOn) {
		LastUpdatedOn = lastUpdatedOn;
	}
	public String getLastUpdatedBy() {
		return LastUpdatedBy;
	}
	public void setLastUpdatedBy(String lastUpdatedBy) {
		LastUpdatedBy = lastUpdatedBy;
	}
	public String getOrgCode() {
		return OrgCode;
	}
	public void setOrgCode(String orgCode) {
		OrgCode = orgCode;
	}
	
	

}
