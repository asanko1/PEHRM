package com.pehrm.bean;

import java.util.Date;

public class PATIENT_INFO {
	String	PID	;
	String	FirstName	;
	String	LastName	;
	String	Phone	;
	String	Emaiil	;
	Date	DOB	;
	String	Age	;
	String	AddressLine1	;
	String	AddressLine2	;
	String	City	;
	String	State	;
	String	PIN	;
	Date	CreatedOn	;
	String	CreatedBy	;
	Date	LastUpdatedOn	;
	String	LastUpdatedBy	;
	String	OrgCode	;
	String Gender;
	
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public PATIENT_INFO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public PATIENT_INFO(String pID, String firstName, String lastName, String phone, String emaiil, Date dOB,
			String age, String addressLine1, String addressLine2, String city, String state, String pIN, Date createdOn,
			String createdBy, Date lastUpdatedOn, String lastUpdatedBy, String orgCode, String gender) {
		super();
		PID = pID;
		FirstName = firstName;
		LastName = lastName;
		Phone = phone;
		Emaiil = emaiil;
		DOB = dOB;
		Age = age;
		AddressLine1 = addressLine1;
		AddressLine2 = addressLine2;
		City = city;
		State = state;
		PIN = pIN;
		CreatedOn = createdOn;
		CreatedBy = createdBy;
		LastUpdatedOn = lastUpdatedOn;
		LastUpdatedBy = lastUpdatedBy;
		OrgCode = orgCode;
		Gender = gender;
	}
	public String getPID() {
		return PID;
	}
	public void setPID(String pID) {
		PID = pID;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getPhone() {
		return Phone;
	}
	public void setPhone(String phone) {
		Phone = phone;
	}
	public String getEmaiil() {
		return Emaiil;
	}
	public void setEmaiil(String emaiil) {
		Emaiil = emaiil;
	}
	public Date getDOB() {
		return DOB;
	}
	public void setDOB(Date dOB) {
		DOB = dOB;
	}
	public String getAge() {
		return Age;
	}
	public void setAge(String age) {
		Age = age;
	}
	public String getAddressLine1() {
		return AddressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		AddressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return AddressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		AddressLine2 = addressLine2;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getPIN() {
		return PIN;
	}
	public void setPIN(String pIN) {
		PIN = pIN;
	}
	public Date getCreatedOn() {
		return CreatedOn;
	}
	public void setCreatedOn(Date createdOn) {
		CreatedOn = createdOn;
	}
	public String getCreatedBy() {
		return CreatedBy;
	}
	public void setCreatedBy(String createdBy) {
		CreatedBy = createdBy;
	}
	public Date getLastUpdatedOn() {
		return LastUpdatedOn;
	}
	public void setLastUpdatedOn(Date lastUpdatedOn) {
		LastUpdatedOn = lastUpdatedOn;
	}
	public String getLastUpdatedBy() {
		return LastUpdatedBy;
	}
	public void setLastUpdatedBy(String lastUpdatedBy) {
		LastUpdatedBy = lastUpdatedBy;
	}
	public String getOrgCode() {
		return OrgCode;
	}
	public void setOrgCode(String orgCode) {
		OrgCode = orgCode;
	}
	
	

}
