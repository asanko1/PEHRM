package com.pehrm.bean;

import java.util.Date;

public class APPNMNT {
	String	APPT_ID	;
	String	PID	;
	String	POV	;
	Date	APT_Date	;
	String	hour	;
	String	min	;
	String	dn	;
	String	LOC_ID	;
	String	DOC_ID	;
	String	emergency_ind	;
	String	PAY_MODE	;
	Date	CreatedOn	;
	String	CreatedBy	;
	Date	LastUpdatedOn	;
	String	LastUpdatedBy	;
	String	STATUS	;
	String	OrgCode	;
	String	bookingMODE	;
	String PAT_NAME;
	String DOC_NAME;
	String LOC_NAME;
	public Date getAPT_Date() {
		return APT_Date;
	}
	public void setAPT_Date(Date aPT_Date) {
		APT_Date = aPT_Date;
	}
	public String getPAT_NAME() {
		return PAT_NAME;
	}
	public void setPAT_NAME(String pAT_NAME) {
		PAT_NAME = pAT_NAME;
	}
	public String getDOC_NAME() {
		return DOC_NAME;
	}
	public void setDOC_NAME(String dOC_NAME) {
		DOC_NAME = dOC_NAME;
	}
	public String getLOC_NAME() {
		return LOC_NAME;
	}
	public void setLOC_NAME(String lOC_NAME) {
		LOC_NAME = lOC_NAME;
	}
	public APPNMNT() {
		super();
		// TODO Auto-generated constructor stub
	}
	public APPNMNT(String aPPT_ID, String pID, String pOV, Date adate, String hour, String min, String dn,
			String lOC_ID, String dOC_ID, String emergency_ind, String pAY_MODE, Date createdOn, String createdBy,
			Date lastUpdatedOn, String lastUpdatedBy, String sTATUS, String orgCode, String bookingMODE) {
		super();
		APPT_ID = aPPT_ID;
		PID = pID;
		POV = pOV;
		APT_Date = adate;
		this.hour = hour;
		this.min = min;
		this.dn = dn;
		LOC_ID = lOC_ID;
		DOC_ID = dOC_ID;
		this.emergency_ind = emergency_ind;
		PAY_MODE = pAY_MODE;
		CreatedOn = createdOn;
		CreatedBy = createdBy;
		LastUpdatedOn = lastUpdatedOn;
		LastUpdatedBy = lastUpdatedBy;
		STATUS = sTATUS;
		OrgCode = orgCode;
		this.bookingMODE = bookingMODE;
	}
	public String getAPPT_ID() {
		return APPT_ID;
	}
	public void setAPPT_ID(String aPPT_ID) {
		APPT_ID = aPPT_ID;
	}
	public String getPID() {
		return PID;
	}
	public void setPID(String pID) {
		PID = pID;
	}
	public String getPOV() {
		return POV;
	}
	public void setPOV(String pOV) {
		POV = pOV;
	}
	public Date getADate() {
		return APT_Date;
	}
	public void setADate(Date adate) {
		APT_Date = adate;
	}
	public String getHour() {
		return hour;
	}
	public void setHour(String hour) {
		this.hour = hour;
	}
	public String getMin() {
		return min;
	}
	public void setMin(String min) {
		this.min = min;
	}
	public String getDn() {
		return dn;
	}
	public void setDn(String dn) {
		this.dn = dn;
	}
	public String getLOC_ID() {
		return LOC_ID;
	}
	public void setLOC_ID(String lOC_ID) {
		LOC_ID = lOC_ID;
	}
	public String getDOC_ID() {
		return DOC_ID;
	}
	public void setDOC_ID(String dOC_ID) {
		DOC_ID = dOC_ID;
	}
	public String getEmergency_ind() {
		return emergency_ind;
	}
	public void setEmergency_ind(String emergency_ind) {
		this.emergency_ind = emergency_ind;
	}
	public String getPAY_MODE() {
		return PAY_MODE;
	}
	public void setPAY_MODE(String pAY_MODE) {
		PAY_MODE = pAY_MODE;
	}
	public Date getCreatedOn() {
		return CreatedOn;
	}
	public void setCreatedOn(Date createdOn) {
		CreatedOn = createdOn;
	}
	public String getCreatedBy() {
		return CreatedBy;
	}
	public void setCreatedBy(String createdBy) {
		CreatedBy = createdBy;
	}
	public Date getLastUpdatedOn() {
		return LastUpdatedOn;
	}
	public void setLastUpdatedOn(Date lastUpdatedOn) {
		LastUpdatedOn = lastUpdatedOn;
	}
	public String getLastUpdatedBy() {
		return LastUpdatedBy;
	}
	public void setLastUpdatedBy(String lastUpdatedBy) {
		LastUpdatedBy = lastUpdatedBy;
	}
	public String getSTATUS() {
		return STATUS;
	}
	public void setSTATUS(String sTATUS) {
		STATUS = sTATUS;
	}
	public String getOrgCode() {
		return OrgCode;
	}
	public void setOrgCode(String orgCode) {
		OrgCode = orgCode;
	}
	public String getBookingMODE() {
		return bookingMODE;
	}
	public void setBookingMODE(String bookingMODE) {
		this.bookingMODE = bookingMODE;
	}
	
	

}
