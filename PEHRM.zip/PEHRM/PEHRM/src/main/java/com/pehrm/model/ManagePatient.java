package com.pehrm.model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.cj.jdbc.CallableStatement;
import com.pehrm.bean.PATIENT_INFO;
import com.pehrm.config.DBConnection;

public class ManagePatient {
	
	public ManagePatient() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String createPatient(PATIENT_INFO PI)
	{
		DBConnection dbcon=new DBConnection();
		String pkey=null;
		Connection con=dbcon.getDBConnection();
		try {
			
			String query = "{CALL sp_get_pkey(?,?,?)}";
			CallableStatement stmt = (CallableStatement) con.prepareCall(query);
			stmt.setString(1, "Patient_Info");
			stmt.setString(2, "PID");
			stmt.registerOutParameter(3, java.sql.Types.VARCHAR);
			stmt.executeQuery();
			 pkey=stmt.getString(3);
			
			System.out.println(pkey);
			PI.setPID(pkey);
			PreparedStatement ps=con.prepareStatement("INSERT INTO Patient_Info values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			ps.setString(1, PI.getPID());
			ps.setString(2, PI.getFirstName());
			ps.setString(3, PI.getLastName());
			ps.setString(4, PI.getPhone());
			ps.setString(5, PI.getEmaiil());
			if(PI.getDOB()!=null) {
			ps.setDate(6, new java.sql.Date(PI.getDOB().getTime()));
			}else {
				ps.setDate(6, null);
			}
			ps.setString(7, PI.getAge());
			ps.setString(8, PI.getAddressLine1());
			
			ps.setString(9, PI.getAddressLine2());
			ps.setString(10, PI.getCity());
			ps.setString(11, PI.getState());
			ps.setString(12, PI.getPIN());
			ps.setDate(13,  new java.sql.Date(PI.getCreatedOn().getTime()));
			ps.setString(14,PI.getCreatedBy());
			ps.setDate(15, new java.sql.Date(PI.getLastUpdatedOn().getTime()));
			ps.setString(16,PI.getLastUpdatedBy());
			ps.setString(17, PI.getOrgCode());
			ps.setString(18, PI.getGender());
			ps.executeUpdate();
			con.close();
			return pkey;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pkey;
	}
	
	public ArrayList<PATIENT_INFO> searchPatient(String phone, String OrgCode) {
		DBConnection dbcon=new DBConnection();
		Connection con=dbcon.getDBConnection();
		PATIENT_INFO PI=null;
		ArrayList<PATIENT_INFO> pat_arr=new ArrayList<PATIENT_INFO>();
		try {
			PreparedStatement ps=con.prepareStatement("SELECT * FROM Patient_Info WHERE Phone=?  and OrgCode=? LIMIT 5");
			ps.setString(1, phone);
			ps.setString(2, OrgCode);
			 PI=new PATIENT_INFO();
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				
				PI=new PATIENT_INFO();
				PI.setPID(rs.getString(1));
				PI.setFirstName(rs.getString(2));
				PI.setLastName(rs.getString(3));
				PI.setPhone(rs.getString(4));
				PI.setEmaiil(rs.getString(5));
				PI.setAddressLine1(rs.getString(8));
				PI.setAddressLine2(rs.getString(9));
				PI.setCity(rs.getString(10));
				PI.setState(rs.getString(11));
				PI.setPIN(rs.getString(12));
				pat_arr.add(PI);
			}
			con.close();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pat_arr;
	}
	
	public PATIENT_INFO getPatientByPID(String phone, String OrgCode) {
		DBConnection dbcon=new DBConnection();
		Connection con=dbcon.getDBConnection();
		PATIENT_INFO PI=null;
		
		try {
			PreparedStatement ps=con.prepareStatement("SELECT * FROM Patient_Info WHERE PID=? and OrgCode=?  ");
			ps.setString(1, phone);
			ps.setString(2, OrgCode);
			 PI=new PATIENT_INFO();
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				
				PI=new PATIENT_INFO();
				PI.setPID(rs.getString(1));
				PI.setFirstName(rs.getString(2));
				PI.setLastName(rs.getString(3));
				PI.setPhone(rs.getString(4));
				PI.setEmaiil(rs.getString(5));
				PI.setDOB(rs.getDate(6));
				PI.setAge(rs.getString(7));
				PI.setAddressLine1(rs.getString(8));
				PI.setAddressLine2(rs.getString(9));
				PI.setCity(rs.getString(10));
				PI.setState(rs.getString(11));
				PI.setPIN(rs.getString(12));
				PI.setOrgCode(rs.getString(17));
				PI.setGender(rs.getString(18));
				
			}
			con.close();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return PI;
	}
	
	public String searchPatientByPID(String pid, String OrgCode) {
		DBConnection dbcon=new DBConnection();
		Connection con=dbcon.getDBConnection();
		String name=null;
		try {
			PreparedStatement ps=con.prepareStatement("SELECT concat(FirstName,' ',LastName) FROM Patient_Info WHERE PID=? and OrgCode=? ");
			ps.setString(1, pid);
			ps.setString(2, OrgCode);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				name=rs.getString(1);
				//System.out.println(name);
			}
			con.close();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return name;
	}
	
	public String getPatientEmailId(String pid, String OrgCode) {
		DBConnection dbcon=new DBConnection();
		Connection con=dbcon.getDBConnection();
		String name=null;
		try {
			PreparedStatement ps=con.prepareStatement("SELECT Emaiil FROM Patient_Info WHERE PID=? and OrgCode=? ");
			ps.setString(1, pid);
			ps.setString(2, OrgCode);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				name=rs.getString(1);
				//System.out.println(name);
			}
			con.close();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return name;
	}
	
	public String getPatientGender(String pid, String OrgCode) {
		DBConnection dbcon=new DBConnection();
		Connection con=dbcon.getDBConnection();
		String gender=null;
		try {
			PreparedStatement ps=con.prepareStatement("SELECT gender FROM Patient_Info WHERE PID=? and OrgCode=? ");
			ps.setString(1, pid);
			ps.setString(2, OrgCode);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				gender=rs.getString(1);
				//System.out.println(name);
			}
			con.close();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return gender;
	}
	
	public String getPatientAge(String pid, String OrgCode) {
		DBConnection dbcon=new DBConnection();
		Connection con=dbcon.getDBConnection();
		String age=null;
		try {
			PreparedStatement ps=con.prepareStatement("SELECT Age FROM Patient_Info WHERE PID=? and OrgCode=? ");
			ps.setString(1, pid);
			ps.setString(2, OrgCode);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				age=rs.getString(1);
				//System.out.println(name);
			}
			con.close();
		}
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return age;
	}
	
	public String searchPatientNameWithouSpaceByPID(String pid, String OrgCode) {
		DBConnection dbcon=new DBConnection();
		Connection con=dbcon.getDBConnection();
		String name=null;
		try {
			PreparedStatement ps=con.prepareStatement("SELECT concat(FirstName,'_',LastName) FROM Patient_Info WHERE PID=? and OrgCode=? ");
			ps.setString(1, pid);
			ps.setString(2, OrgCode);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				name=rs.getString(1);
				//System.out.println(name);
			}
			con.close();
		}
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return name;
	}
	public int updatePatient(PATIENT_INFO PI, String OrgCode)
	{
		DBConnection dbcon=new DBConnection();
		String pkey=null;
		Connection con=dbcon.getDBConnection();
		int i=0;
		try {
			
			
			
			PreparedStatement ps=con.prepareStatement("Update Patient_Info set 	FirstName=?,	LastName=?,	Phone=?,	Emaiil=?,	DOB=?,	Age=?,	AddressLine1=?,	AddressLine2=?,	City=?,	State=?,	PIN=?,		LastUpdatedOn=?,	LastUpdatedBy=?,		gender=? WHERE PID=? and OrgCode=? ");
			
			ps.setString(1, PI.getFirstName());
			ps.setString(2, PI.getLastName());
			ps.setString(3, PI.getPhone());
			ps.setString(4, PI.getEmaiil());
			if(PI.getDOB()!=null) {
			ps.setDate(5, new java.sql.Date(PI.getDOB().getTime()));
			}else {
				ps.setDate(5, null);
			}
			ps.setString(6, PI.getAge());
			ps.setString(7, PI.getAddressLine1());
			
			ps.setString(8, PI.getAddressLine2());
			ps.setString(9, PI.getCity());
			ps.setString(10, PI.getState());
			ps.setString(11, PI.getPIN());
			
			ps.setDate(12, new java.sql.Date(PI.getLastUpdatedOn().getTime()));
			ps.setString(13,PI.getLastUpdatedBy());
			
			ps.setString(14, PI.getGender());
			ps.setString(15, PI.getPID());
			ps.setString(16, OrgCode);
			i=ps.executeUpdate();
			con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}
	
}
