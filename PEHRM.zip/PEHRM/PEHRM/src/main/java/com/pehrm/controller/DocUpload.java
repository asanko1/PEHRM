package com.pehrm.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemIterator;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.tomcat.util.http.fileupload.FileItemStream;

import com.pehrm.model.FilePath;

/**
 * Servlet implementation class DocUpload
 */
public class DocUpload extends HttpServlet implements FilePath {
	private static final long serialVersionUID = 1L;
	private static final int MEMORY_THRESHOLD = 1024 * 1024 * 3; // 3MB
	private static final int MAX_FILE_SIZE = 1024 * 1024 * 40; // 40MB
	private static final int MAX_REQUEST_SIZE = 1024 * 1024 * 50; // 50MB

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DocUpload() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	System.out.println("file upload");

		String pat_id = null;
		if (!ServletFileUpload.isMultipartContent(request)) {
			// if not, we stop here
			PrintWriter writer = response.getWriter();
			writer.println("Error: Form must has enctype=multipart/form-data.");
			writer.flush();
			return;
		}
		DiskFileItemFactory factory = new DiskFileItemFactory();
		factory.setSizeThreshold(MEMORY_THRESHOLD);
		factory.setRepository(new File(System.getProperty("java.io.tmpdir")));
		ServletFileUpload upload = new ServletFileUpload(factory);
		
		try {

			@SuppressWarnings("unchecked")
			List<FileItem> uploadItems = upload.parseRequest(request);

			for (FileItem uploadItem : uploadItems) {
				if (uploadItem.isFormField()) {
					String fieldName = uploadItem.getFieldName();
					String value = uploadItem.getString();
					if (fieldName.equals("pat_id")) {
						pat_id = value;
					}
				} else {
					String fileName = new File(uploadItem.getName()).getName();
					String uploadpath=config_path + File.separator + "DocRepo" + File.separator + pat_id;
					String filePath = config_path + File.separator + "DocRepo" + File.separator + pat_id
							+ File.separator + fileName;
					File uploadDir = new File(uploadpath);
					if (!uploadDir.exists()) {
						uploadDir.mkdir();
					}
					//System.out.println(filePath);
					File storeFile = new File(filePath);

					// saves the file on disk
					uploadItem.write(storeFile);
				//	System.out.println("Upload has been done successfully!");
				}
			}
		} catch (FileUploadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		RequestDispatcher rd = request.getRequestDispatcher("/Homepage.jsp?docid=d");
		rd.forward(request, response);
	}

}
