package com.pehrm.bean;

import java.util.Date;

public class ENCOUNTER_RCD {
	String	EID	;
	String	PID	;
	String	DOC_ID	;
	String	Complaints	;
	String	Measurements	;
	String	Advices	;
	Date	CreatedOn	;
	String	CreatedBy	;
	Date	LastUpdatedOn	;
	String	LastUpdatedBy	;
	String	OrgCode	;
	String	MedicalHistory	;
	String	CurrentMedications	;
	String	DrugAllergy	;
	String pat_name;
	String doc_name;
	String doc_reg_no;
	String usertype;
	public String getUsertype() {
		return usertype;
	}
	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}
	public String getPat_name() {
		return pat_name;
	}
	public void setPat_name(String pat_name) {
		this.pat_name = pat_name;
	}
	public String getDoc_name() {
		return doc_name;
	}
	public void setDoc_name(String doc_name) {
		this.doc_name = doc_name;
	}
	public String getDoc_reg_no() {
		return doc_reg_no;
	}
	public void setDoc_reg_no(String doc_reg_no) {
		this.doc_reg_no = doc_reg_no;
	}
	public ENCOUNTER_RCD(String eID, String pID, String dOC_ID, String complaints, String measurements, String advices,
			Date createdOn, String createdBy, Date lastUpdatedOn, String lastUpdatedBy, String orgCode,
			String medicalHistory, String currentMedications, String drugAllergy) {
		super();
		EID = eID;
		PID = pID;
		DOC_ID = dOC_ID;
		Complaints = complaints;
		Measurements = measurements;
		Advices = advices;
		CreatedOn = createdOn;
		CreatedBy = createdBy;
		LastUpdatedOn = lastUpdatedOn;
		LastUpdatedBy = lastUpdatedBy;
		OrgCode = orgCode;
		MedicalHistory = medicalHistory;
		CurrentMedications = currentMedications;
		DrugAllergy = drugAllergy;
	}
	public ENCOUNTER_RCD() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getEID() {
		return EID;
	}
	public void setEID(String eID) {
		EID = eID;
	}
	public String getPID() {
		return PID;
	}
	public void setPID(String pID) {
		PID = pID;
	}
	public String getDOC_ID() {
		return DOC_ID;
	}
	public void setDOC_ID(String dOC_ID) {
		DOC_ID = dOC_ID;
	}
	public String getComplaints() {
		return Complaints;
	}
	public void setComplaints(String complaints) {
		Complaints = complaints;
	}
	public String getMeasurements() {
		return Measurements;
	}
	public void setMeasurements(String measurements) {
		Measurements = measurements;
	}
	public String getAdvices() {
		return Advices;
	}
	public void setAdvices(String advices) {
		Advices = advices;
	}
	public Date getCreatedOn() {
		return CreatedOn;
	}
	public void setCreatedOn(Date createdOn) {
		CreatedOn = createdOn;
	}
	public String getCreatedBy() {
		return CreatedBy;
	}
	public void setCreatedBy(String createdBy) {
		CreatedBy = createdBy;
	}
	public Date getLastUpdatedOn() {
		return LastUpdatedOn;
	}
	public void setLastUpdatedOn(Date lastUpdatedOn) {
		LastUpdatedOn = lastUpdatedOn;
	}
	public String getLastUpdatedBy() {
		return LastUpdatedBy;
	}
	public void setLastUpdatedBy(String lastUpdatedBy) {
		LastUpdatedBy = lastUpdatedBy;
	}
	public String getOrgCode() {
		return OrgCode;
	}
	public void setOrgCode(String orgCode) {
		OrgCode = orgCode;
	}
	public String getMedicalHistory() {
		return MedicalHistory;
	}
	public void setMedicalHistory(String medicalHistory) {
		MedicalHistory = medicalHistory;
	}
	public String getCurrentMedications() {
		return CurrentMedications;
	}
	public void setCurrentMedications(String currentMedications) {
		CurrentMedications = currentMedications;
	}
	public String getDrugAllergy() {
		return DrugAllergy;
	}
	public void setDrugAllergy(String drugAllergy) {
		DrugAllergy = drugAllergy;
	}

	
}
