package com.pehrm.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.Properties;

import com.pehrm.model.FilePath;

public class DBConnection implements FilePath{
	
	Connection con=null;
	
	public DBConnection() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Connection getDBConnection()
	{
		
		Properties prop=new Properties(); 
		
		
		try {
			//FileInputStream ip= new FileInputStream(config_path+File.separator+"config"+File.separator+"config.properties");
			FileInputStream ip= new FileInputStream(config_path+File.separator+"config"+File.separator+"config.properties");
			prop.load(ip);
			Class.forName("com.mysql.cj.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://"+prop.getProperty("dbhostname")+":"+prop.getProperty("dbport")+"/"+prop.getProperty("dbname"),prop.getProperty("user"),prop.getProperty("pwd"));  
			//System.out.println(con);
			return con;
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return con;
	}

	public static void main(String[] args) {
		
		new DBConnection().getDBConnection();
	}

}
