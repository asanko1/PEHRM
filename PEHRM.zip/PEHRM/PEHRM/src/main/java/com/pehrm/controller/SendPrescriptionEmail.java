package com.pehrm.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pehrm.model.ManagePatient;
import com.pehrm.model.SendPrescription;

/**
 * Servlet implementation class SendPrescriptionEmail
 */
public class SendPrescriptionEmail extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SendPrescriptionEmail() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String pat_email=request.getParameter("pat_email");
		String pat_id=request.getParameter("pat_id");
		
		ManagePatient mp=new ManagePatient();
		HttpSession session=request.getSession();
		String pat_name=mp.searchPatientByPID(pat_id, session.getAttribute("ccode").toString());
		String pat_name_nospace=mp.searchPatientNameWithouSpaceByPID(pat_id, session.getAttribute("ccode").toString());
		System.out.println("Here"+pat_id+pat_email+pat_name+pat_name_nospace);
		SendPrescription send=new SendPrescription();
		send.sendPrescription(pat_email, pat_name_nospace, pat_id, pat_name);
			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
