package com.pehrm.bean;

import java.sql.Date;

/**
 * @author asank
 *
 */
public class LOGIN {
	String email;
	
	String name;
	Date last_login;
	String ccode;
	String usertype;
	public String getUsertype() {
		return usertype;
	}
	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}
	
	public LOGIN(String email, String name, Date last_login, String ccode, String usertype) {
		super();
		this.email = email;
		this.name = name;
		this.last_login = last_login;
		this.ccode = ccode;
		this.usertype = usertype;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getLast_login() {
		return last_login;
	}
	public void setLast_login(Date last_login) {
		this.last_login = last_login;
	}
	public String getCcode() {
		return ccode;
	}
	public void setCcode(String ccode) {
		this.ccode = ccode;
	}
	
	
	
}
