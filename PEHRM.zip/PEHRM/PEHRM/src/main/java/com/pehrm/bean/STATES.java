package com.pehrm.bean;

public class STATES {
	String statename;
	String Country;
	
	
	public STATES() {
		super();
		// TODO Auto-generated constructor stub
	}
	public STATES(String statename, String country) {
		super();
		this.statename = statename;
		Country = country;
	}
	public String getStatename() {
		return statename;
	}
	public void setStatename(String statename) {
		this.statename = statename;
	}
	public String getCountry() {
		return Country;
	}
	public void setCountry(String country) {
		Country = country;
	}
	
}
