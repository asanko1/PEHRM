package com.pehrm.bean;

import java.util.Date;

public class DOCTOR_INFO {
	String	ID	;
	String	FirstName	;
	String	LastName	;
	String	Phone	;
	String	Emaiil	;
	String	Degree	;
	String	Specialization	;
	String	ExperienceSummary	;
	String	RegistrationNo	;
	String	RegistrationAuthority	;
	Date	CreatedOn	;
	String	CreatedBy	;
	Date	LastUpdatedOn	;
	String	LastUpdatedBy	;
	String	OrgCode	;
	public DOCTOR_INFO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DOCTOR_INFO(String iD, String firstName, String lastName, String phone, String emaiil, String degree,
			String specialization, String experienceSummary, String registrationNo, String registrationAuthority,
			Date createdOn, String createdBy, Date lastUpdatedOn, String lastUpdatedBy, String orgCode) {
		super();
		ID = iD;
		FirstName = firstName;
		LastName = lastName;
		Phone = phone;
		Emaiil = emaiil;
		Degree = degree;
		Specialization = specialization;
		ExperienceSummary = experienceSummary;
		RegistrationNo = registrationNo;
		RegistrationAuthority = registrationAuthority;
		CreatedOn = createdOn;
		CreatedBy = createdBy;
		LastUpdatedOn = lastUpdatedOn;
		LastUpdatedBy = lastUpdatedBy;
		OrgCode = orgCode;
	}
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getPhone() {
		return Phone;
	}
	public void setPhone(String phone) {
		Phone = phone;
	}
	public String getEmaiil() {
		return Emaiil;
	}
	public void setEmaiil(String emaiil) {
		Emaiil = emaiil;
	}
	public String getDegree() {
		return Degree;
	}
	public void setDegree(String degree) {
		Degree = degree;
	}
	public String getSpecialization() {
		return Specialization;
	}
	public void setSpecialization(String specialization) {
		Specialization = specialization;
	}
	public String getExperienceSummary() {
		return ExperienceSummary;
	}
	public void setExperienceSummary(String experienceSummary) {
		ExperienceSummary = experienceSummary;
	}
	public String getRegistrationNo() {
		return RegistrationNo;
	}
	public void setRegistrationNo(String registrationNo) {
		RegistrationNo = registrationNo;
	}
	public String getRegistrationAuthority() {
		return RegistrationAuthority;
	}
	public void setRegistrationAuthority(String registrationAuthority) {
		RegistrationAuthority = registrationAuthority;
	}
	public Date getCreatedOn() {
		return CreatedOn;
	}
	public void setCreatedOn(Date createdOn) {
		CreatedOn = createdOn;
	}
	public String getCreatedBy() {
		return CreatedBy;
	}
	public void setCreatedBy(String createdBy) {
		CreatedBy = createdBy;
	}
	public Date getLastUpdatedOn() {
		return LastUpdatedOn;
	}
	public void setLastUpdatedOn(Date lastUpdatedOn) {
		LastUpdatedOn = lastUpdatedOn;
	}
	public String getLastUpdatedBy() {
		return LastUpdatedBy;
	}
	public void setLastUpdatedBy(String lastUpdatedBy) {
		LastUpdatedBy = lastUpdatedBy;
	}
	public String getOrgCode() {
		return OrgCode;
	}
	public void setOrgCode(String orgCode) {
		OrgCode = orgCode;
	}
	
	

}
