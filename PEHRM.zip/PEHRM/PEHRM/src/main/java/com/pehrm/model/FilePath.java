package com.pehrm.model;

public interface FilePath {
	String config_path="C:\\Users\\asank\\eclipse-workspace\\PEHRM";
	//String config_path=(System.getProperty("user.dir"));
}
