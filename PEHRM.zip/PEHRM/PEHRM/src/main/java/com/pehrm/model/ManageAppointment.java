package com.pehrm.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import com.mysql.cj.jdbc.CallableStatement;
import com.pehrm.bean.APPNMNT;
import com.pehrm.bean.APPT_RQST;
import com.pehrm.config.DBConnection;

public class ManageAppointment {
	ArrayList<APPNMNT> ap_arr=null;
	public String createAppointment(APPNMNT A) {
		DBConnection dbcon = new DBConnection();
		String pkey = null;
		Connection con = dbcon.getDBConnection();
		
		try {

			String query = "{CALL sp_get_pkey(?,?,?)}";
			CallableStatement stmt = (CallableStatement) con.prepareCall(query);
			stmt.setString(1, "APPT_RCD");
			stmt.setString(2, "APPT_ID");
			stmt.registerOutParameter(3, java.sql.Types.VARCHAR);
			stmt.executeQuery();
			pkey = stmt.getString(3);

			System.out.println(pkey);
			A.setAPPT_ID(pkey);
			PreparedStatement ps = con
					.prepareStatement("INSERT INTO APPT_RCD values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			ps.setString(1, A.getAPPT_ID());
			ps.setString(2, A.getPID());
			ps.setString(3, A.getPOV());
			ps.setDate(4, new java.sql.Date(A.getADate().getTime()));
			ps.setString(5, A.getHour());
			ps.setString(6, A.getMin());
			ps.setString(7, A.getDn());
			ps.setString(8, A.getLOC_ID());

			ps.setString(9, A.getDOC_ID());
			ps.setString(10, A.getEmergency_ind());
			ps.setString(11, A.getPAY_MODE());
			ps.setDate(12, new java.sql.Date(A.getCreatedOn().getTime()));
			ps.setString(13, A.getCreatedBy());
			ps.setDate(14, new java.sql.Date(A.getLastUpdatedOn().getTime()));
			ps.setString(15, A.getLastUpdatedBy());
			ps.setString(16, "CONFIRMED");
			ps.setString(17, A.getOrgCode());
			ps.setString(18, A.getBookingMODE());
			ps.executeUpdate();
			con.close();
			return A.getAPPT_ID();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return A.getAPPT_ID();
	}

	public ArrayList<APPNMNT> searchAppointment(String companycode, Date fd, Date td) {
		DBConnection dbcon = new DBConnection();
		String pkey = null;
		Connection con = dbcon.getDBConnection();
		try {
			PreparedStatement ps = con.prepareStatement("select APPT_ID, PID, POV, Apt_Date, hour, min, dn, LOC_ID, DOC_ID, emergency_ind, PAY_MODE, LastUpdatedOn, LastUpdatedBy, STATUS,  bookingMODE from APPT_RCD WHERE OrgCode=? "
					+ "								and Apt_Date>=? and Apt_Date<=? and OrgCode=? order by Apt_Date,dn,hour,min");
			ps.setString(1, companycode);
			ps.setDate(2, new java.sql.Date(fd.getTime()));
			ps.setDate(3, new java.sql.Date(td.getTime()));
			ps.setString(4, companycode);
			ResultSet rs=ps.executeQuery();
			APPNMNT ap=new APPNMNT();
			ap_arr=new ArrayList<APPNMNT>();
			while(rs.next()) {
				ap=new  APPNMNT();
				ap.setAPPT_ID(rs.getString(1));
				ap.setPID(rs.getString(2));
				ap.setPOV(rs.getString(3));
				ap.setADate(rs.getDate(4));
				ap.setHour(rs.getString(5));
				ap.setMin(rs.getString(6));
				ap.setDn(rs.getString(7));
				ap.setLOC_ID(rs.getString(8));
				ap.setDOC_ID(rs.getString(9));
				ap.setEmergency_ind(rs.getString(10));
				ap.setPAY_MODE(rs.getString(11));
				ap.setLastUpdatedOn(rs.getDate(12));
				ap.setLastUpdatedBy(rs.getString(13));
				ap.setSTATUS(rs.getString(14));
				ap.setBookingMODE(rs.getString(15));
				ap_arr.add(ap);
				
			}
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return ap_arr;
		
	}
	
	public APPNMNT searchAppointmentbyId(String companycode, String apt_id) {
		DBConnection dbcon = new DBConnection();
		String pkey = null;
		Connection con = dbcon.getDBConnection();
		APPNMNT ap=new APPNMNT();
		try {
			PreparedStatement ps = con.prepareStatement("select APPT_ID, PID, POV, Apt_Date, hour, min, dn, LOC_ID, DOC_ID, emergency_ind, PAY_MODE, LastUpdatedOn, LastUpdatedBy, STATUS,  bookingMODE from APPT_RCD WHERE OrgCode=? "
					+ "								and APPT_ID=? and OrgCode=? order by Apt_Date,dn,hour,min");
			ps.setString(1, companycode);
			ps.setString(2, apt_id);
			ps.setString(3, companycode);
			
			ResultSet rs=ps.executeQuery();
			
			ap_arr=new ArrayList<APPNMNT>();
			while(rs.next()) {
				ap=new  APPNMNT();
				ap.setAPPT_ID(rs.getString(1));
				ap.setPID(rs.getString(2));
				ap.setPOV(rs.getString(3));
				ap.setADate(rs.getDate(4));
				ap.setHour(rs.getString(5));
				ap.setMin(rs.getString(6));
				ap.setDn(rs.getString(7));
				ap.setLOC_ID(rs.getString(8));
				ap.setDOC_ID(rs.getString(9));
				ap.setEmergency_ind(rs.getString(10));
				ap.setPAY_MODE(rs.getString(11));
				ap.setLastUpdatedOn(rs.getDate(12));
				ap.setLastUpdatedBy(rs.getString(13));
				ap.setSTATUS(rs.getString(14));
				ap.setBookingMODE(rs.getString(15));
				
				
			}
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ap;
		
	}
	
	public String updateAppointment(APPNMNT A, String OrgCode) {
		DBConnection dbcon = new DBConnection();
		String pkey = null;
		Connection con = dbcon.getDBConnection();
		
		try {

			
			PreparedStatement ps = con
					.prepareStatement("UPDATE APPT_RCD set PID=?, POV=?, Apt_Date=?, hour=?, min=?, dn=?, LOC_ID=?, DOC_ID=?, emergency_ind=?, PAY_MODE=?,  LastUpdatedOn=?, LastUpdatedBy=?, STATUS=?, bookingMODE=? WHERE APPT_ID=? and OrgCode=? ");
			
			ps.setString(1, A.getPID());
			ps.setString(2, A.getPOV());
			ps.setDate(3, new java.sql.Date(A.getADate().getTime()));
			ps.setString(4, A.getHour());
			ps.setString(5, A.getMin());
			ps.setString(6, A.getDn());
			ps.setString(7, A.getLOC_ID());

			ps.setString(8, A.getDOC_ID());
			ps.setString(9, A.getEmergency_ind());
			ps.setString(10, A.getPAY_MODE());
			
			ps.setDate(11, new java.sql.Date(A.getLastUpdatedOn().getTime()));
			ps.setString(12, A.getLastUpdatedBy());
			ps.setString(13, "CONFIRMED");
			
			ps.setString(14, A.getBookingMODE());
			ps.setString(15, A.getAPPT_ID());
			ps.setString(16, OrgCode);
			ps.executeUpdate();
			con.close();
			return A.getAPPT_ID();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return A.getAPPT_ID();
	}
	
	public String saveAppointmentRequest(APPT_RQST AR) {
		DBConnection dbcon = new DBConnection();
		String pkey = null;
		Connection con = dbcon.getDBConnection();
		
		try {

			String query = "{CALL sp_get_pkey(?,?,?)}";
			CallableStatement stmt = (CallableStatement) con.prepareCall(query);
			stmt.setString(1, "APPT_RQST");
			stmt.setString(2, "RQST_ID");
			stmt.registerOutParameter(3, java.sql.Types.VARCHAR);
			stmt.executeQuery();
			pkey = stmt.getString(3);

			System.out.println(pkey);
			AR.setRQST_ID(pkey);
			PreparedStatement ps = con
					.prepareStatement("INSERT INTO APPT_RQST values (?,?,?,?,?,?)");
			ps.setString(1, AR.getRQST_ID());
			ps.setString(2, AR.getName());
			ps.setString(3,AR.getPhone());
			ps.setString(4, AR.getOrgcode());
			ps.setString(5,AR.getEmail());
			ps.setString(6, AR.getStatus());
			ps.executeUpdate();
			
		}catch(Exception e) {
			
		}
		return pkey;
	}
	
	public ArrayList<APPT_RQST> getNewAppointments(String orgCode) {
		ArrayList<APPT_RQST> app_arr=new ArrayList<APPT_RQST>();
		APPT_RQST app=new APPT_RQST();
		DBConnection dbcon = new DBConnection();
		
		Connection con = dbcon.getDBConnection();
		try {
		PreparedStatement ps = con.prepareStatement(" SELECT RQST_ID, Name, PhoneNumber,  email,status from APPT_RQST WHERE OrgCode=? and status=? ");
		ps.setString(1, orgCode);
		ps.setString(2, "New");
		
		ResultSet rs=ps.executeQuery();
		
		while(rs.next()) {
			
			app=new APPT_RQST();
			app.setRQST_ID(rs.getString(1));
			app.setName(rs.getString(2));
			app.setPhone(rs.getString(3));
			app.setEmail(rs.getString(4));
			app.setStatus(rs.getString(5));
			app_arr.add(app);
			
		}
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		return app_arr;
		
		
	}
	
	public int updateAppointmentRequest(String req_id, String orgCode) {
		
		DBConnection dbcon = new DBConnection();
		Connection con = dbcon.getDBConnection();
		int c=0;
		try {
			
			PreparedStatement ps = con.prepareStatement(" update APPT_RQST set status=? where OrgCode=? and RQST_ID=? ");
			ps.setString(1, "Resolved");
			ps.setString(2, orgCode);
			ps.setString(3, req_id);
			c=ps.executeUpdate();
			
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return c;
	}
}
