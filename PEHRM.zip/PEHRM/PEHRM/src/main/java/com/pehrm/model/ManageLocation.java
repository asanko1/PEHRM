package com.pehrm.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.cj.jdbc.CallableStatement;
import com.pehrm.bean.LOC_DTL;
import com.pehrm.bean.PATIENT_INFO;
import com.pehrm.config.DBConnection;

public class ManageLocation {
	public String createLocation(LOC_DTL l)
	{
		DBConnection dbcon=new DBConnection();
		String pkey=null;
		Connection con=dbcon.getDBConnection();
		try {
			
			String query = "{CALL sp_get_pkey(?,?,?)}";
			CallableStatement stmt = (CallableStatement) con.prepareCall(query);
			stmt.setString(1, "Location_DTL");
			stmt.setString(2, "LOC_ID");
			stmt.registerOutParameter(3, java.sql.Types.VARCHAR);
			stmt.executeQuery();
			pkey = stmt.getString(3);
			
			System.out.println(pkey);
			l.setLOC_ID(pkey);
			PreparedStatement ps=con.prepareStatement("INSERT INTO Location_DTL values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			ps.setString(1, l.getLOC_ID());
			ps.setString(2, l.getLOC_NM());
			ps.setString(3, l.getAddressLine1());
			ps.setString(4, l.getAddressLine2());
			ps.setString(5, l.getCity());			
			ps.setString(6, l.getState());			
			ps.setString(7, l.getPIN());
			ps.setString(8, l.getPhone1());
			ps.setString(9, l.getPhone2());
			ps.setString(10, l.getEmail());
			ps.setDate(11,  new java.sql.Date(l.getCreatedOn().getTime()));
			ps.setString(12,l.getCreatedBy());
			ps.setDate(13, new java.sql.Date(l.getLastUpdatedOn().getTime()));
			ps.setString(14,l.getLastUpdatedBy());
			ps.setString(15, l.getOrgCode());
			ps.executeUpdate();
			con.close();
			return pkey;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pkey;
	}
	public ArrayList<LOC_DTL> getAllLocations(String companycode){
		DBConnection dbcon=new DBConnection();
		Connection con=dbcon.getDBConnection();
		LOC_DTL LD=null;
		ArrayList<LOC_DTL> loc_arr=new ArrayList<LOC_DTL>();
		try {
			PreparedStatement ps=con.prepareStatement("SELECT * FROM Location_DTL WHERE OrgCode=? ");
			ps.setString(1, companycode);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				LD=new LOC_DTL();
				LD.setLOC_ID(rs.getString(1));
				LD.setLOC_NM(rs.getString(2));
				LD.setPhone1(rs.getString(8));
				LD.setEmail(rs.getString(10));
				LD.setAddressLine1(rs.getString(3));
				LD.setAddressLine2(rs.getString(4));
				LD.setCity(rs.getString(5));
				LD.setState(rs.getString(6))	;
				LD.setPIN(rs.getString(7));
				LD.setPhone2(rs.getString(9));
				loc_arr.add(LD);
				
			}
			con.close();
			return loc_arr;
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return loc_arr;
	}
	public String searchLocationByID(String pid, String OrgCode) {
		DBConnection dbcon=new DBConnection();
		Connection con=dbcon.getDBConnection();
		String name=null;
		try {
			PreparedStatement ps=con.prepareStatement("SELECT LOC_NM FROM Location_DTL WHERE LOC_ID=? and OrgCode=? ");
			ps.setString(1, pid);
			ps.setString(2, OrgCode);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				name=rs.getString(1);
			}
			con.close();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return name;
	}
}
