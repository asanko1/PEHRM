package com.pehrm.model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.pehrm.bean.LOGIN;
import com.pehrm.config.DBConnection;

public class ManageLogin {
	String name=null,ccode=null,usertype=null;
	Date dt=null;
	LOGIN lg=null;
	public LOGIN checkLogin(String email,String pwd,String orgcode) {
		DBConnection dbcon=new DBConnection();
		Connection con=dbcon.getDBConnection();
		try {
		PreparedStatement ps=con.prepareStatement("select name,last_login,orgcode,usertype from login WHERE email=? and password=? and orgcode=?");
		ps.setString(1, email);
		ps.setString(2, pwd);
		ps.setString(3, orgcode);
		ResultSet rs=ps.executeQuery();
		
		while(rs.next())  {
			name=rs.getString(1); 
			dt=rs.getDate(2);
			ccode=rs.getString(3);
			usertype=rs.getString(4);
		}
		lg=new LOGIN(email,name,dt,ccode,usertype);
		 ps=con.prepareStatement("update login set last_login=? where email=? and password=? and orgcode=?");
		 ps.setDate(1, new java.sql.Date(new java.util.Date().getTime()));
		 ps.setString(2, email);
			ps.setString(3, pwd);
			ps.setString(4, orgcode);
			ps.executeUpdate();
		con.close();  
		}catch(Exception e)
		{ System.out.println(e);}  
		
		return lg;
	}
}
